﻿
using System;
using NSBDesignPatterns.Messages.Commands;
using NServiceBus;

namespace NSBDesignPatterns.Client
{
    class Program
    {
        static void Main(string[] args)
        {
            var busConfig = new BusConfiguration();
            busConfig.UsePersistence<InMemoryPersistence>();
            busConfig.Conventions()
                .DefiningCommandsAs(t => t.Namespace != null && t.Namespace.Contains("Messages.Commands"));
            var bus = Bus.CreateSendOnly(busConfig);
            bus.Send(new CreateOrderCommand()
            {
                OrderId = Guid.NewGuid(),
                CustomerId = Guid.NewGuid(),
                Address1 = "Address1",
                Address2 = "Address2",
                Country = "Australia",
                Email = "customer1@test.com",
                FirstName = "John",
                LastName = "Ng",
                Postcode = "2000",
                State = "NSW",
                Suburb = "Sydney"
            });
        }
    }
}

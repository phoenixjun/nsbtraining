﻿using System.Collections.Generic;
using System.Linq;
using Ninject;
using NSBDesignPatterns.Domain.Infrastructure;
using NSBDesignPatterns.Domain.Infrastructure.Interface;
using NSBDesignPatterns.Domain.Models;
using NSBDesignPatterns.Persistence.EF;
using NUnit.Framework;

namespace NSBDesignPatterns.UnitTests.Persistence.EF
{
    [TestFixture]
    public class UpdateDatabaseToLatestVersion
    {
        [Test, Explicit]
        public void UpdateDatabase()
        {
            var kernel = new StandardKernel();
            kernel.Bind<IRepository>().To<Repository>();
            kernel.Bind<IUnitOfWork>().To<NSBPatternContext>();

            IRepository repository = kernel.Get<IRepository>();
            List<Customer> members = repository.LoadList<Customer>(m => true).ToList();
        }
    }
}

﻿using System;
using Moq;
using NSBDesignPatterns.Domain.Exceptions;
using NSBDesignPatterns.Domain.Infrastructure.Interface;
using NSBDesignPatterns.Domain.Models;
using NUnit.Framework;

namespace NSBDesignPatterns.UnitTests.Domain.Models
{
    [TestFixture]
    public class CustomerTests
    {
        private const string Existingemail = "ExistingEmail";
        private const string FirstName = "FirstName";
        private const string LastName = "lastName";
        private Mock<IDuplicateCustomerEmail> _duplicateCustomerEmailMock;

        [SetUp]
        public void Setup()
        {
            _duplicateCustomerEmailMock = new Mock<IDuplicateCustomerEmail>();
        }    
        [Test]
        public void CustomerFullName_ShouldReturnAsExpectedFormat()
        {
            var customer = new Customer(Guid.NewGuid(), FirstName, LastName, "Email",
                _duplicateCustomerEmailMock.Object);
            Assert.AreEqual(string.Format("{0} {1}", FirstName, LastName), customer.FullName);

        }


        [Test]
        [ExpectedException(typeof(DuplicateEmailException))]
        public void ShouldThrowException_WhenEmailExist()
        {
            _duplicateCustomerEmailMock.Setup(
                x => x.IsSatisfiedBy(It.Is<Customer>(c => c.Email.Equals(Existingemail)))).Returns(true);
            var customer = new Customer(Guid.NewGuid(), FirstName, LastName, Existingemail,
                _duplicateCustomerEmailMock.Object);
        }
    }
}

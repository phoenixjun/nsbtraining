﻿using AutoMapper;
using NSBDesignPatterns.Handlers.Mapping;
using NUnit.Framework;

namespace NSBDesignPatterns.UnitTests.Handlers.Mapping
{
    [TestFixture]
    public class AutoMapperConfiguration
    {
        [Test]
        public void AutoMapper_ShouldConfigureCorrectly()
        {
            Mapper.Initialize(
                cfg =>
                {
                    cfg.AddProfile(new HandlersMappingProfile());
                });

            Mapper.AssertConfigurationIsValid();
        }
    }
}

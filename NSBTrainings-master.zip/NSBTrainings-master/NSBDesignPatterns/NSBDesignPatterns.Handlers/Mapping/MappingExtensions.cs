﻿using System.Linq;
using AutoMapper;

namespace NSBDesignPatterns.Handlers.Mapping
{
    public static class MappingExtensions
    {

        public static TDest MapTo<TDest>(this object source) where TDest : class
        {
            return source == null ? null : Mapper.Map<TDest>(source);
        }

        public static IQueryable<TDest> QueryMapTo<TSource, TDest>(this IQueryable<TSource> query)
            where TDest : class
            where TSource : class
        {
            return query.Select(x => x.MapTo<TDest>());
        }
    }
}

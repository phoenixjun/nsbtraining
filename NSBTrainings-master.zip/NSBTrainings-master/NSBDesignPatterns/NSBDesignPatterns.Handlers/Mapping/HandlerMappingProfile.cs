﻿using AutoMapper;
using NSBDesignPatterns.Messages.Commands;

namespace NSBDesignPatterns.Handlers.Mapping
{
    public class HandlersMappingProfile : Profile
    {
        protected override void Configure()
        {
            Mapper.CreateMap<Sagas.Data.OrderProcessorState, CreateCustomerCommand>();
        }
    }
}

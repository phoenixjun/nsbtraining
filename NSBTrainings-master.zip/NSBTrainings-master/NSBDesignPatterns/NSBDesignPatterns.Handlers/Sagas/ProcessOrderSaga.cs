﻿using NSBDesignPatterns.Domain.Infrastructure.Interface;
using NSBDesignPatterns.Domain.Models;
using NSBDesignPatterns.Handlers.Mapping;
using NSBDesignPatterns.Handlers.Sagas.Data;
using NSBDesignPatterns.Messages.Commands;
using NSBDesignPatterns.Messages.Events;
using NServiceBus;
using NServiceBus.Saga;

namespace NSBDesignPatterns.Handlers.Sagas
{
    public class OrderProcessor : Saga<OrderProcessorState>, IAmStartedByMessages<CreateOrderCommand>, IHandleMessages<ICustomerCreated>
    {
        private readonly IRepository _repository;
        public OrderProcessor(IRepository repository)
        {
            _repository = repository;
        }

        protected override void ConfigureHowToFindSaga(SagaPropertyMapper<OrderProcessorState> mapper)
        {
            mapper.ConfigureMapping<CreateOrderCommand>(m => m.OrderId).ToSaga(s => s.OrderId);
            mapper.ConfigureMapping<ICustomerCreated>(m => m.CustomerId).ToSaga(s => s.CustomerId);
        }

        public void Handle(CreateOrderCommand message)
        {
            Data.CustomerId = message.CustomerId;
            Data.Email = message.Email;
            Data.FirstName = message.FirstName;
            Data.LastName = message.LastName;
            Data.OrderId = message.OrderId;


            // ensure the customer exists, if not, create it
            var customer = _repository.Load<Customer>(x => x.CustomerId == message.CustomerId);
            if (customer == null)
            {
                // decouple the customer creation from handling the command
                Bus.Send(Data.MapTo<CreateCustomerCommand>());
                return;
            }

            ProcessOrder();
        }

        /// <summary>
        /// function to process the order
        /// </summary>
        private void ProcessOrder()
        {
            // handler in unit of work
            CreateOrder();
            EndOrderProcess();
        }

        /// <summary>
        /// handle the ICustomerCreatedEvent
        /// </summary>
        /// <param name="message"></param>
        public void Handle(ICustomerCreated message)
        {
            ProcessOrder();
        }

        void CreateOrder()
        {
            var order = new Domain.Models.Order(Data.OrderId, Data.CustomerId, string.Format("{0} {1}", Data.FirstName, Data.LastName),
                                                Data.Address1, Data.Address2, Data.Suburb, Data.State, Data.Postcode, Data.Country);
            _repository.Add(order);
        }

        void EndOrderProcess()
        {
            Bus.Publish<IOrderCreated>(e =>
            {
                e.OrderId = Data.OrderId;
            });

            MarkAsComplete();
        }
    }
}

﻿using System;
using NServiceBus.Saga;

namespace NSBDesignPatterns.Handlers.Sagas.Data
{
    public class OrderProcessorState : IContainSagaData
    {
        public virtual Guid Id { get; set; }
        public virtual string Originator { get; set; }
        public virtual string OriginalMessageId { get; set; }

        public virtual Guid CustomerId { get; set; }
        public virtual string Email { get; set; }
        public virtual string FirstName { get; set; }
        public virtual string LastName { get; set; }

        public virtual Guid OrderId { get; set; }
        public virtual string Address1 { get; set; }
        public virtual string Address2 { get; set; }
        public virtual string Suburb { get; set; }
        public virtual string State { get; set; }
        public virtual string Postcode { get; set; }
        public virtual string Country { get; set; }
    }
}

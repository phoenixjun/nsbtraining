﻿using System;
using NSBDesignPatterns.Domain.Exceptions;
using NSBDesignPatterns.Domain.Infrastructure.Interface;

namespace NSBDesignPatterns.Domain.Models
{
    public class Customer
    {
        public Guid CustomerId { get; private set; }
        public string FirstName { get; private set; }
        public string LastName { get; private set; }
        public string Email { get; private set; }

        public string FullName
        {
            get
            {
                return string.Format("{0} {1}", string.IsNullOrEmpty(FirstName) ? string.Empty : FirstName,
                    string.IsNullOrEmpty(LastName) ? string.Empty : LastName);
            }
        }

        internal Customer() { }
        public Customer(Guid id, string firstName, string lastName, string email, IDuplicateCustomerEmail duplicateCustomerEmail)
        {
            CustomerId = id;
            FirstName = firstName;
            LastName = lastName;
            Email = email;

            if (duplicateCustomerEmail.IsSatisfiedBy(this))
                throw new DuplicateEmailException(email);
        }

    }
}

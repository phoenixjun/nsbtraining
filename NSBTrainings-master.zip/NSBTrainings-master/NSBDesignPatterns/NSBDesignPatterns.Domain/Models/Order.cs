﻿using System;
using NSBDesignPatterns.Domain.Enums;

namespace NSBDesignPatterns.Domain.Models
{
    public class Order
    {
        public Guid OrderId { get; private set; }
        public Guid CustomerId { get; private set; }
        public string CustomerFullName { get; private set; }

        public Address ShippingAddress { get; private set; }
        public OrderStatus OrderStatus { get; private set; }

        internal Order()
        {

        }

        public Order(Guid orderId, Guid customerId, string customerFullName, string address1, string address2,
            string suburb, string state, string postcode, string country)
        {
            OrderId = orderId;
            CustomerId = customerId;
            CustomerFullName = customerFullName;
            OrderStatus = OrderStatus.Draft;
            ShippingAddress = new Address()
            {
                Address1 = address1,
                Address2 = address2,
                Country = country,
                Suburb = suburb,
                Postcode = postcode,
                State = state
            };
        }
    }

    public sealed class Address
    {
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string Suburb { get; set; }
        public string Postcode { get; set; }
        public string State { get; set; }
        public string Country { get; set; }
    }

}

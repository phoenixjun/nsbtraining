﻿using NSBDesignPatterns.Domain.Infrastructure.Interface;
using NSBDesignPatterns.Domain.Models;

namespace NSBDesignPatterns.Domain.Specifications
{
    public class DuplicateCustomerEmail : IDuplicateCustomerEmail
    {
        readonly IRepository _repository;


        public DuplicateCustomerEmail(IRepository repository)
        {
            _repository = repository;
        }

        public bool IsSatisfiedBy(Customer entity)
        {
            // customer must have a unique email address
            var anyCustomer = _repository.Exists<Customer>(customers => customers.Email == entity.Email);
            return anyCustomer;
        }
    }
}

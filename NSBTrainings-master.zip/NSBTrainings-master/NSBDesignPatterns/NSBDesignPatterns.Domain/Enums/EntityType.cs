﻿
namespace NSBDesignPatterns.Domain.Enums
{
    public enum EntityType
    {
        Customer,
        Order
    }
}

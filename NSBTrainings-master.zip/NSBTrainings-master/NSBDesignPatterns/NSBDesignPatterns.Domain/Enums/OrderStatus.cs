﻿
namespace NSBDesignPatterns.Domain.Enums
{

    public enum OrderStatus
    {
        Draft,
        Processing,
        Shipped,
        Complete
    }

}

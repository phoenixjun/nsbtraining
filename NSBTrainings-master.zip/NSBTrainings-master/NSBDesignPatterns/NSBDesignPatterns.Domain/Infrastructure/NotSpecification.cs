﻿using System;
using NSBDesignPatterns.Domain.Infrastructure.Interface;

namespace NSBDesignPatterns.Domain.Infrastructure
{
    internal class NotSpecification<TEntity> : ISpecification<TEntity>
    {
        readonly ISpecification<TEntity> _wrapped;

        protected ISpecification<TEntity> Wrapped
        {
            get
            {
                return _wrapped;
            }
        }
        internal NotSpecification(ISpecification<TEntity> spec)
        {
            if (spec == null)
            {
                throw new ArgumentNullException("spec");
            }

            _wrapped = spec;
        }
        public bool IsSatisfiedBy(TEntity candidate)
        {
            return !Wrapped.IsSatisfiedBy(candidate);
        }
    }
}
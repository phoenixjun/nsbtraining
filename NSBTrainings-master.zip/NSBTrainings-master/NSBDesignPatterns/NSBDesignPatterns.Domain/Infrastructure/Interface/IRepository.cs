﻿using System;
using System.Linq;
using System.Linq.Expressions;

namespace NSBDesignPatterns.Domain.Infrastructure.Interface
{
    public interface IRepository
    {
        void Add<TAggregate>(TAggregate aggregate) where TAggregate : class;

        TAggregate Load<TAggregate>(Expression<Func<TAggregate, bool>> predicate, params Expression<Func<TAggregate, object>>[] includes) where TAggregate : class;

        IQueryable<TAggregate> LoadList<TAggregate>(Expression<Func<TAggregate, bool>> predicate, params Expression<Func<TAggregate, object>>[] includes) where TAggregate : class;

        bool Exists<TAggregate>(Expression<Func<TAggregate, bool>> predicate) where TAggregate : class;

        /// <summary>
        /// this is specific for NSB just to make sure the NSB is re-using the connection from service bus
        /// </summary>
        /// <param name="unitOfWork"></param>
        void UseExistingUnitOfWork(Lazy<IUnitOfWork> unitOfWork);

        void CommitChanges();
    }
}

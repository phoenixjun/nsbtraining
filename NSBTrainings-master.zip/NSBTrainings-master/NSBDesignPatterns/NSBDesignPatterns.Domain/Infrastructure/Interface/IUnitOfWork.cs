
namespace NSBDesignPatterns.Domain.Infrastructure.Interface
{
    public interface IUnitOfWork
    {
    }
}


namespace NSBDesignPatterns.Domain.Infrastructure.Interface
{
    public interface ISpecification<TEntity>
    {
        bool IsSatisfiedBy(TEntity entity);
    }
}

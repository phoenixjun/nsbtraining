using NSBDesignPatterns.Domain.Models;

namespace NSBDesignPatterns.Domain.Infrastructure.Interface
{
    public interface IDuplicateCustomerEmail : ISpecification<Customer>
    {
    }
}
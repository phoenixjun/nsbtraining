
using AutoMapper;
using Ninject;
using Ninject.Modules;
using NSBDesignPatterns.Domain.Infrastructure.Interface;
using NSBDesignPatterns.Domain.Specifications;
using NSBDesignPatterns.Handlers.Mapping;
using NSBDesignPatterns.Persistence.EF;
using NServiceBus.Logging;

namespace NSBDesignPatterns.Host
{
    using NServiceBus;

    /*
		This class configures this endpoint as a Server. More information about how to configure the NServiceBus host
		can be found here: http://particular.net/articles/the-nservicebus-host
	*/

    public class EndpointConfig : IConfigureThisEndpoint
    {
        public void Customize(BusConfiguration configuration)
        {
            // NServiceBus provides the following durable storage options
            // To use RavenDB, install-package NServiceBus.RavenDB and then use configuration.UsePersistence<RavenDBPersistence>();
            // To use SQLServer, install-package NServiceBus.NHibernate and then use configuration.UsePersistence<NHibernatePersistence>();

            // If you don't need a durable storage you can also use, configuration.UsePersistence<InMemoryPersistence>();
            // more details on persistence can be found here: http://docs.particular.net/nservicebus/persistence-in-nservicebus

            //Also note that you can mix and match storages to fit you specific needs. 
            //http://docs.particular.net/nservicebus/persistence-order

            configuration.RegisterComponents(
                c => c.ConfigureComponent<ManageUnitOfWork>(DependencyLifecycle.InstancePerUnitOfWork));
            configuration.RegisterComponents(
                c => c.ConfigureComponent<Repository>(DependencyLifecycle.InstancePerUnitOfWork));

            configuration.UseContainer<NinjectBuilder>(k => k.ExistingKernel(CreateKernel()));
            configuration.UsePersistence<NHibernatePersistence>();
            configuration.UseTransport<MsmqTransport>();
            configuration.RijndaelEncryptionService();
            configuration.EnableOutbox();
            configuration.Transactions().DisableDistributedTransactions(); // we need to use NSB without MSDTC
            configuration.Conventions().UseSampleConventions();
            ConfigureMapping();
        }

        private IKernel CreateKernel()
        {
            var kernel = new StandardKernel();

            kernel.Bind<ILog>().ToMethod(context => LogManager.GetLogger(context.Request.Target.Member.DeclaringType));
            kernel.Bind<IDuplicateCustomerEmail>().To<DuplicateCustomerEmail>();
            return kernel;
        }

        private void ConfigureMapping()
        {
            Mapper.Initialize(
                cfg =>
                {
                    cfg.AddProfile(new HandlersMappingProfile());
                });

            Mapper.AssertConfigurationIsValid();
        }
    }
}

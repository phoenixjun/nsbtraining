﻿using System;
using System.Data.Common;
using System.Data.Entity;
using NSBDesignPatterns.Domain.Infrastructure;
using NSBDesignPatterns.Domain.Infrastructure.Interface;
using NSBDesignPatterns.Persistence.EF;
using NServiceBus.Logging;
using NServiceBus.Persistence.NHibernate;
using NServiceBus.UnitOfWork;

namespace NSBDesignPatterns.Host
{
    /// <summary>
    /// implemenation of the UnitOfWork in NSB
    /// </summary>
    /// <remarks>
    /// Handles two cross cutting concern for logging and exception handling
    /// </remarks>
    public class ManageUnitOfWork : IManageUnitsOfWork
    {
        private readonly ILog _logger;
        private readonly NHibernateStorageContext _nHibernateStorageContext;
        private readonly IRepository _repository;


        public ManageUnitOfWork(ILog logger, NHibernateStorageContext nHibernateStorageContext,
            IRepository repository)
        {
            _logger = logger;
            _nHibernateStorageContext = nHibernateStorageContext;
            _repository = repository;
        }

        public void Begin()
        {
            // when the message starts, let the repository to use the connection from existing nHibernateContext and let it manage the connection
            _repository.UseExistingUnitOfWork(new Lazy<IUnitOfWork>(() =>
                new NSBPatternContext((DbConnection) _nHibernateStorageContext.Connection)
                ));
        }

        public void End(Exception ex = null)
        {
            // if there is exception, don't commit anything
            if (ex != null)
            {
                _logger.Error("NServiceBus unhandled exception", ex);
                return;
            }
            CommitChanges();
        }

        private void CommitChanges()
        {
            try
            {
                _repository.CommitChanges();
            }
            catch (Exception exc)
            {
                _logger.Error("Commit failed:" + exc.Message, exc);
                // throw the exception so that NSB can rollback the transaction within the scope as well
                throw;
            }
        }
    }
}

﻿using System;

namespace NSBDesignPatterns.Messages.Events
{
    public interface IOrderCreated
    {
        Guid OrderId { get; set; }
    }
}

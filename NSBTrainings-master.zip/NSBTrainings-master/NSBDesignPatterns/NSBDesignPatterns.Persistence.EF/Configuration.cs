﻿using System.Data.Entity.Migrations;

namespace NSBDesignPatterns.Persistence.EF
{
    internal sealed class Configuration : DbMigrationsConfiguration<NSBPatternContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
        }

        protected override void Seed(NSBPatternContext context)
        {

        }
    }


}

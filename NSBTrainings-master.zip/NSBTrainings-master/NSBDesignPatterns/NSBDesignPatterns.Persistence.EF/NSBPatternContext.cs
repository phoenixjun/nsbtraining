﻿using System.Data.Common;
using System.Data.Entity;
using NSBDesignPatterns.Domain.Infrastructure;
using NSBDesignPatterns.Domain.Infrastructure.Interface;
using NSBDesignPatterns.Domain.Models;

namespace NSBDesignPatterns.Persistence.EF
{
    public class NSBPatternContext : DbContext, IUnitOfWork
    {
        public NSBPatternContext()
            : base("NSBPatternContext")
        {
            
        }

        public NSBPatternContext(DbConnection dbConnection)
            // the connection is managed by the NSB and getting passed in from external
            : base(dbConnection, false)
        {
            Configuration.LazyLoadingEnabled = false;
            Configuration.ProxyCreationEnabled = false;
        }

        public IDbSet<Order> Orders { get; set; }
        public IDbSet<Customer> Products { get; set; }
    }
}
# NSBTrainings
application for NServiceBus projects

1. NSB Hello World
- project structure (Message, Host, Handlers, Client)
- Queue explorer
- transaction
- command send and receive
- how to debug
- configuration
- unicast config

2. Send and receive, publish and subscriber
3. Saga
4. Transactions


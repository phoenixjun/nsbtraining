﻿using NServiceBus;

namespace NSB.Messages.Commands
{
    public class HelloWorldCommand : ICommand
    {
        public string Message { get; set; }
    }
}

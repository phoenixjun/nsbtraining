﻿
using NSB.Messages.Commands;
using NServiceBus;

namespace NSB.Client
{
    class Program
    {
        static void Main(string[] args)
        {
            var busConfig = new BusConfiguration();
            busConfig.UsePersistence<InMemoryPersistence>();
            var bus = Bus.CreateSendOnly(busConfig);
            bus.Send(new HelloWorldCommand() {Message = "Hellow Everyone!"});
        }
    }
}

﻿using System;
using System.Transactions;
using System.Web.Mvc;
using ApplicationUnitOfWork.Models;
using NSBUnitOfWork.Messages.Commands;
using NServiceBus;

namespace ApplicationUnitOfWork.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            ViewBag.Title = "Home Page";
            var busConfig = new BusConfiguration();
            busConfig.UsePersistence<InMemoryPersistence>();
            using (var t = new TransactionScope(TransactionScopeOption.RequiresNew, new TransactionOptions() {IsolationLevel = IsolationLevel.ReadCommitted}))
            {
                var context = new UnitOfWorkContext();
                context.Customers.Add(new Customer());
                context.SaveChanges();
                var bus = Bus.CreateSendOnly(busConfig);
                bus.Send(new CreateOrderCommand() {OrderId = Guid.NewGuid()});
                DoSomethingElse();
                bus.Send(new NotificationCommand() {NotificationId = Guid.NewGuid()});
                t.Complete();
            }
            return View();
        }

        private void DoSomethingElse()
        {
            throw new System.NotImplementedException();

        }
    }
}

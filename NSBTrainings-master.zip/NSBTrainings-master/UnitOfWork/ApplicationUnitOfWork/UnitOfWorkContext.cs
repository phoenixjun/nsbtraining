﻿using System.Configuration;
using System.Data.Entity;
using ApplicationUnitOfWork.Models;

namespace ApplicationUnitOfWork
{
    public class UnitOfWorkContext : DbContext
    {
        public UnitOfWorkContext()
            : base("UnitOfWorkContext")
        {
            Database.SetInitializer();
            
        }

        public DbSet<Customer> Customers { get; set; }
        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Configurations.Add(new CustomerMap());

        }
    }
}
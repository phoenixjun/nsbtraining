﻿using System;
using NSBUnitOfWork.Messages.Commands;
using NServiceBus;

namespace NSBUnitOfWork.Handlers
{
    public class CreateOrderCommandHandler : IHandleMessages<CreateOrderCommand>
    {
        public void Handle(CreateOrderCommand message)
        {
            throw new NotImplementedException();
        }
    }
}

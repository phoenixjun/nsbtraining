﻿using System;
using NSBUnitOfWork.Messages.Commands;
using NServiceBus;

namespace NSBUnitOfWork.Handlers
{
    public class NotificationCommandHandler : IHandleMessages<NotificationCommand>
    {
        public void Handle(NotificationCommand message)
        {
            throw new NotImplementedException();
        }
    }
}

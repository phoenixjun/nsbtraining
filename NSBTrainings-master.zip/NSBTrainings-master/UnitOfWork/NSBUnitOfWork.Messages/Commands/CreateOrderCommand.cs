﻿using System;
using NServiceBus;

namespace NSBUnitOfWork.Messages.Commands
{
    public class CreateOrderCommand : ICommand
    {
        public Guid OrderId { get; set; }
    }
}

﻿using System;
using NServiceBus;

namespace NSBUnitOfWork.Messages.Commands
{
    public class NotificationCommand : ICommand
    {
        public Guid NotificationId { get; set; }
    }
}

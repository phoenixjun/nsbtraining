# TechChallenge
What I have used:
- .Net Framework 4.5, ASP MVC 5
- MVC Skeleton online project template
- AutoMapper, NInject, CSVHelper, Bootstrap
- TDD approach, Domain Driven Design approach

How to run the project:
- Open the sln file in Visual studio 2013
- Build the solution (Dependent Nuget packages will be automaticall downloaded)
- Click F5 (Run the Gambling.Portal project - set as startup project) - it will use IIS Express to show the portal



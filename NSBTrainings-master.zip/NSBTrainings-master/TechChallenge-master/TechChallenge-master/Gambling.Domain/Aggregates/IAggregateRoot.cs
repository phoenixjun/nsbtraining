﻿namespace Gambling.Domain.Aggregates
{
    public interface IAggregateRoot
    {
    }
}
namespace Gambling.Domain.Aggregates
{
    public class Constants
    {
        public const decimal unusualRateThreshHold = 0.6m;

        public const decimal highWinAmountThreshHold = 1000m;
    }
}
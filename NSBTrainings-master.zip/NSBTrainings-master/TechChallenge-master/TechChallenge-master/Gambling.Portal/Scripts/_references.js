﻿/// <autosync enabled="true" />
/// <reference path="jquery-2.1.4.js" />
/// <reference path="bootstrap.js" />
/// <reference path="jquery-ui-1.11.4.js" />
/// <reference path="jquery.validate.js" />
/// <reference path="jquery.validate.unobtrusive.js" />

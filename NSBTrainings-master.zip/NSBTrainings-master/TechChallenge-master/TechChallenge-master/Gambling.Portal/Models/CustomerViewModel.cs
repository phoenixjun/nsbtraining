﻿namespace Gambling.Portal.Models
{
    public class CustomerViewModel
    {
        public int Id { get; set; }
    }
}
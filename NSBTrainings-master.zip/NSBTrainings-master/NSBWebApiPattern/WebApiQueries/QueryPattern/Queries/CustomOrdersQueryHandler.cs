﻿
namespace WebApiQueries.QueryPattern.Queries
{
    public class CustomOrdersQueryHandler : IQueryHandler<IQuery<CustomerOrders.Result>, CustomerOrders.Result>
    {
        public QueryResult<CustomerOrders.Result> Handle(IQuery<CustomerOrders.Result> query)
        {
            throw new System.NotImplementedException();
        }
    }
}

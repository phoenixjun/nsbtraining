﻿using System;

namespace WebApiQueries.QueryPattern.Queries
{
    public sealed class CustomerOrders : IQuery<CustomerOrders.Result>
    {
        public Guid? CustomerId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }

        public class Result
        {
            public Guid OrderId;
            public decimal TotalValue;
            public decimal TotalPaid;
            public decimal TotalOutstanding;
        }
    }
}

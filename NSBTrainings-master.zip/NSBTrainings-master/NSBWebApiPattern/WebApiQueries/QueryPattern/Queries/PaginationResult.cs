﻿
namespace WebApiQueries.QueryPattern.Queries
{
    public sealed class PaginationResult<TResult>
    {
        public TResult[] Results { get; set; }
        public int TotalFound { get; set; }
        public int PageIndex { get; set; }
        public int PageSize { get; set; }
    }
}

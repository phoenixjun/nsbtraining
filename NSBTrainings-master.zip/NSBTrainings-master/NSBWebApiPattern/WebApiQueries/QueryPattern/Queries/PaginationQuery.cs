﻿
namespace WebApiQueries.QueryPattern.Queries
{
    public class PaginationQuery<T> : IQuery<PaginationResult<T>>
    {
        public int PageIndex { get; set; }

        public int PageSize { get; set; }

        public SortOrder SortOrder { get; set; }

        public string SortCriteria { get; set; }
    }


    public enum SortOrder
    {
        Ascending,
        Descending
    }
}

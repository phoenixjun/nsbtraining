﻿
namespace WebApiQueries.QueryPattern
{
    /// <summary>
    /// defines the query with result
    /// </summary>
    /// <typeparam name="TResult"></typeparam>
    public interface IQuery<TResult>
    {

    }
}

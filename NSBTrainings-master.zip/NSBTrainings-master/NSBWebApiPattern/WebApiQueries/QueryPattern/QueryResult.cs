﻿
namespace WebApiQueries.QueryPattern
{
    public sealed class QueryResult<TResult>
    {
        public TResult[] Results { get; set; }

        public int TotalFound { get; set; }

        public int PageIndex { get; set; }

        public int PageSize { get; set; }

        public int TotalPages { get; set; }
    }
}

﻿
namespace WebApiQueries.QueryPattern
{
    public class CriteriaBase
    {
        public int PageIndex { get; set; }

        public int PageSize { get; set; }

        public string SortOrder { get; set; }

        public string SortCriteria { get; set; }
    }
}

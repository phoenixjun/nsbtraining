﻿
namespace WebApiQueries
{
    public class EntityBase
    {
    }
}

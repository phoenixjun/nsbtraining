﻿jQuery(function ($) {
    var dataTableWrapper = new MasterCard.Case.DataTableWraper();
    dataTableWrapper.InitializeTables();
});

var MasterCard = MasterCard || {};
MasterCard.Case = MasterCard.Case || {};

MasterCard.Case.DataTableWraper = (function () {
    function readColumns(tableId) {
        var columns = $("#" + tableId + ">thead>tr>th[data-colname]");
        var dataColumns = [];

        for (var i = 0; i < columns.length; i++) {
            var column = columns[i];
            var colData = {
                "sName": $(column).attr('data-colname'),
                "sWidth": $(column).attr('data-sWidth'),
                "bSortable": $(column).attr('data-bsortable') == undefined ? false : $(column).attr('data-bsortable') === 'true',
                "sTitle": $(column).attr('data-column-header'),
                "bVisible": $(column).attr('data-bvisible') == undefined ? true : $(column).attr('data-bvisible') === 'true',
                "sClass": $(column).attr('data-align') == undefined ? '' : $(column).attr('data-align'),
            };
            //when checkbox
            if ($(column).attr('data-col-type') == "checkbox") {
                colData["mRender"] = function (data, type, full) {
                    var isChecked = data == 'True';
                    return '<input type="checkbox" ' + (isChecked ? 'checked' : '') + ' class="editor-active">';
                };
            }
            //when hyperlink
            if ($(column).attr('data-col-type') == "hyperlink") {
                colData["mRender"] = function (data, type, full) {
                    var tokens = data.split("|");
                    var url = tokens[0];
                    var txt = tokens[1];
                    return '<a href="' + url + '" class="grid-hyperlink">' + txt + '</a>';
                };
            }
            //when raw html
            if ($(column).attr('data-col-type') == "rawhtml") {
                colData["mRender"] = function (data, type, full) {
                    return data;
                };
            }
            dataColumns.push(colData);
        }
        return dataColumns;
    };

    function readDefaultSorting(tableId) {
        var sort = $("#" + tableId).attr('data-default-sorting');
        if (sort == null || sort.length == 0) {
            return [];
        }
        var pairs = sort.split('|');
        var defaultSorting = [];
        for (var i = 0; i < pairs.length; i++) {
            var pair = pairs[i];
            var index = pair.split(',')[0];
            var sorting = pair.split(',')[1];
            defaultSorting.push([index, sorting]);
        }
        return defaultSorting;
    };

    function handleSelectionEvent(table, tableId) {
        $('#' + tableId + ' tbody').on('click', 'tr', function () {
            if ($(this).hasClass('selected')) {
                $(this).removeClass('selected');
            }
            else {
                table.$('tr.selected').removeClass('selected');
                $(this).addClass('selected');
            }
        });
    }

    function InitializeTables(tabId) {

        $('.jquerydatatable').each(function () {
            var tableId = $(this).attr('id');
            if (typeof tabId != 'undefined' && tabId != tableId) {
                return;
            }
            var table = $(this);
            var aoColumns = readColumns(tableId);
            var aaSorting = readDefaultSorting(tableId);
            var deferLoading = parseInt(table.attr('data-deferloading'));
            if (isNaN(deferLoading)) deferLoading = null; // setting null will force the datatables to load data on firsta 

            var oTable = table.dataTable({
                "sDom": 'rt<"bottom"ip><"clear">',
                "iDisplayLength": parseInt(table.attr('data-page-size')),
                "bProcessing": true,
                "bServerSide": true,
                "sAjaxSource": table.attr('data-source-url'),
                "sServerMethod": "POST",
                "aaSorting": aaSorting,
                "aoColumns": aoColumns,
                "fnServerParams": function (aoData) {
                    var searchFormId = table.attr('data-search-form-id');
                    if (searchFormId == null) {
                        return;
                    }

                    var inputs = $('#' + searchFormId + ' [name]');
                    if (inputs == null) {
                        return;
                    }
                    inputs.each(function () {
                        var name = $(this).attr('name');
                        var value = $(this).val();
                        aoData.push({ 'name': name, 'value': value });
                    });
                },
                "fnCreatedRow": function (nRow, aData, iDataIndex) {
                    $(nRow).attr('primaryId', aData[0]);
                    $(nRow).attr('secondaryId', aData[1]);
                },
                //These 3 don't work. the th cells of will be totally dealigned against the td cells
                //"sScrollX": "100%",
                //"sScrollXInner": "180%",
                //"bScrollCollapse": true
                //So, I used http://stackoverflow.com/questions/13178039/datatables-header-alignment-issue
                "bScrollAutoCss": true,
                "iDeferLoading": deferLoading,
            });
            $('<div style="width:100%;overflow: auto"></div>').append(table).insertAfter($('#' + tableId + '_wrapper div').first());

            handleSelectionEvent(oTable, tableId);
        });
    };

    function GetTable(tableId) {
        if (!tableId) {
            tableId = 'dataTable';
        }
        return $('#' + tableId).dataTable();
    };

    function UpdateTableUrl(table, url) {
        var fnSettings = table.fnSettings();
        fnSettings.sAjaxSource = url;
        table._fnAjaxUpdate(fnSettings);
    };

    function RefreshTable(tableId, parameters) {
        var table = GetTable(tableId, parameters);
        if (parameters) {
            var url = table.attr('data-source-url') + parameters;
            UpdateTableUrl(table, url);
            return false;
        }
        table.fnDraw();

        return false;
    };


    function LoadTable(tableId, url) {
        var table = GetTable(tableId);
        if (url) {
            UpdateTableUrl(table, url);
            return false;
        }
        table.fnDraw();

        return false;
    };

    function ShowColumn(index, visible, tableId) {
        GetTable(tableId).fnSetColumnVis(index, visible);
        return false;
    };

    function ReadListOfValuesForColumn(columnIndex, tableId) {

        var list = [];
        var oTable = GetTable(tableId);
        var columnType = GetColumnType(columnIndex, tableId);
        var renderedNodes = $(oTable.fnGetNodes());
        $('#' + tableId + ' tbody tr').each(function (index) {
            var position = oTable.fnGetPosition(this); // getting the row position
            var value;
            if (columnType.isCheckBox) {
                value = $(renderedNodes[index]).find('td:nth-child(' + columnIndex + ') input:checkbox').is(':checked');
            } else {
                value = oTable.fnGetData(position)[columnIndex]; // getting the value of the column
            }
            list.push(value);
        });
        return list;
    };

    function GetColumnType(columnIndex, tableId) {
        var result = {
            isCheckBox: false,
            isNotSpecial: false
        };
        var isCheckBox = $('#' + tableId + ' thead tr th:nth-child(' + columnIndex + ')').attr('data-col-type') == 'checkbox';
        if (isCheckBox) {
            result.isCheckBox = true;
            return result;
        }
        result.isNotSpecial = false;
        return result;
    };


    return {
        InitializeTables: InitializeTables,
        RefreshTable: RefreshTable,
        LoadTable: LoadTable,
        ShowColumn: ShowColumn,
        ReadListOfValuesForColumn: ReadListOfValuesForColumn,
    };
});

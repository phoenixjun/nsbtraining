﻿using System.Collections.Generic;

namespace WebApiQueries.DataTableGrid.Models
{
    public class PagedData<T>
    {
        public IList<T> Page { get; set; }
        public int TotalMatchedEntries { get; set; }
    }
}

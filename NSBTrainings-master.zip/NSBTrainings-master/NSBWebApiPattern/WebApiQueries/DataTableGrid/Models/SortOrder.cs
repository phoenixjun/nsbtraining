﻿
namespace WebApiQueries.DataTableGrid.Models
{
    public enum SortOrder
    {
        Ascendant = 1,
        Descendant = 2
    }
}

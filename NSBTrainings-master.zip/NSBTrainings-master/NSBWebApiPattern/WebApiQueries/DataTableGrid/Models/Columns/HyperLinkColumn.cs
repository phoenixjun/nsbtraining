﻿namespace WebApiQueries.DataTableGrid.Models.Columns
{
    public class HyperLinkColumn : ColumnSettings
    {
        public HyperLinkColumn()
        {
            Sortable = false;
        }
    }
}
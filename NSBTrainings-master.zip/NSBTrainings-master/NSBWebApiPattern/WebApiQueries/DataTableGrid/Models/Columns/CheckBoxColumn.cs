﻿
namespace WebApiQueries.DataTableGrid.Models.Columns
{
    public class CheckBoxColumn : ColumnSettings
    {
        public CheckBoxColumn()
        {
            Sortable = false;
        }
    }
}
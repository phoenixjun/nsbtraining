﻿namespace WebApiQueries.DataTableGrid.Models.Columns
{
    public class RawHtmlColumn : ColumnSettings
    {
    }
}
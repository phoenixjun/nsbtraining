﻿using System;
using System.Collections.Generic;

namespace WebApiQueries.DataTableGrid.Models
{
    public class GridResponse
    {
        public string sEcho { get; set; }
        public int iTotalRecords { get; set; }
        public int iTotalDisplayRecords { get; set; }
        public IList<string[]> aaData { get; set; }

        public static GridResponse GetFrom<T>(GridRequestCriteria criteria, PagedData<T> data,
            Func<PagedData<T>, List<string[]>> serializer)
        {
            var response = new GridResponse();
            response.sEcho = criteria.Echo;
            response.iTotalRecords = data.TotalMatchedEntries;
            response.iTotalDisplayRecords = data.TotalMatchedEntries;
            response.aaData = serializer(data);
            return response;
        }
    }
}
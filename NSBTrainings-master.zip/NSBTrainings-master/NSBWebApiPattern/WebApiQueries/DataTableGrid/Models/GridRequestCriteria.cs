﻿

using WebApiQueries.DataTableGrid.Criterias;

namespace WebApiQueries.DataTableGrid.Models
{
    public class GridRequestCriteria
    {
        public GridCriteria GridCriteria { get; set; }
        public string Echo { get; set; }
        public string Search { get; set; }
        public int NoOfColumns { get; set; }
        public int NoOfSortingColumns { get; set; }
    }
}
﻿using WebApiQueries.DataTableGrid.Criterias;
using System.Collections.Generic;
using System.Linq;
using WebApiQueries.QueryPattern.Infrastructure;
using WebApiQueries.QueryPattern.Queries;

namespace WebApiQueries.DataTableGrid
{
    public static class QueryableExtensions
    {
        public static IQueryable<T> GetSortedPage<T>(this IQueryable<T> source, GridCriteria gridCriteria)
        {
            if (source == null || gridCriteria == null)
            {
                return source;
            }
            return source.OrderBy(gridCriteria.SortCriteria)
                .Skip(gridCriteria.Pagination.StartIndex)
                .Take(gridCriteria.Pagination.PageSize);
        }

        public static IList<T> GetSortedPageAsList<T>(this IQueryable<T> source, GridCriteria gridCriteria)
        {
            if (source == null)
            {
                return null;
            }
            return GetSortedPage(source, gridCriteria).ToList();
        }

        public static IQueryable<T> OrderBy<T>(this IQueryable<T> source, List<SortCriteria> sortData)
        {
            if (sortData == null || sortData.Count == 0)
            {
                return source.OrderBy(s => true);
            }
            IOrderedQueryable<T> result = null;
            for (int i = 0; i < sortData.Count; i++)
            {
                SortCriteria sort = sortData[i];
                string property = sort.PropertyName;
                switch (sort.SortOrder)
                {
                    case SortOrder.Ascending:
                        result = i == 0 ? source.OrderBy(property) : result.ThenBy(property);
                        break;
                    case SortOrder.Descending:
                        result = i == 0 ? source.OrderByDescending(property) : result.ThenByDescending(property);
                        break;
                }
            }
            return result;
        }
    }
}

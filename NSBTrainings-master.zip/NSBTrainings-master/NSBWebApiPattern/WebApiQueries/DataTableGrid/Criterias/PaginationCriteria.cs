﻿namespace WebApiQueries.DataTableGrid.Criterias
{
    public class PaginationCriteria
    {
        public int PageSize { get; set; }
        public int StartIndex { get; set; }
    }
}
﻿

using WebApiQueries.DataTableGrid.Models;

namespace WebApiQueries.DataTableGrid.Criterias
{
    public class SortCriteria
    {
        public SortCriteria(string propertyName, SortOrder sortOrder)
        {
            PropertyName = propertyName;
            SortOrder = sortOrder;
        }

        public string PropertyName { get; set; }
        public SortOrder SortOrder { get; set; }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace WebApiQueries.DataTableGrid
{
    public static class DataTablesExtensions
    {
        public static MvcHtmlString RenderGridFor(this HtmlHelper helper, GridSettings gridSettings)
        {
            ReadDisplayNameFromLocalizationAttributesIfNotOverriden(gridSettings);


            var table = new TagBuilder("table");
            table.AddCssClass("table table-bordered jquerydatatable table-hover");
            table.MergeAttribute("id", gridSettings.GridId);
            if (!string.IsNullOrWhiteSpace(gridSettings.SearchFormId))
            {
                table.MergeAttribute("data-search-form-id", gridSettings.SearchFormId);
            }
            table.MergeAttribute("data-source-url", gridSettings.DataSourceUrl);
            table.MergeAttribute("data-deferLoading", gridSettings.DeferLoading);
            table.MergeAttribute("data-page-size", gridSettings.PageSize.ToString());
            string defaultSorting = BuildDefaultSorting(gridSettings);
            table.MergeAttribute("data-default-sorting", defaultSorting);

            var tHead = new TagBuilder("thead");
            foreach (ColumnSettings column in gridSettings.Columns)
            {
                var th = new TagBuilder("th");
                th.MergeAttribute("data-colname", column.Name);
                if (!string.IsNullOrEmpty(column.Align))
                {
                    th.MergeAttribute("data-align", column.Align);
                }

                if (!column.Visible)
                {
                    th.MergeAttribute("data-bvisible", "false");
                }
                if (!string.IsNullOrWhiteSpace(column.Width))
                {
                    th.MergeAttribute("data-swidth", column.Width);
                }
                th.MergeAttribute("data-column-header", column.DisplayName);

                if (column is CheckBoxColumn)
                {
                    th.MergeAttribute("data-col-type", "checkbox");
                }
                if (column is HyperLinkColumn)
                {
                    th.MergeAttribute("data-col-type", "hyperlink");
                }
                if (column is RawHtmlColumn)
                {
                    th.MergeAttribute("data-col-type", "rawhtml");
                }

                if (column.Sortable && !(column is CheckBoxColumn))
                {
                    th.MergeAttribute("data-bsortable", "true");
                }
                tHead.InnerHtml += th.ToString();
            }
            table.InnerHtml += tHead.ToString();
            var tBody = new TagBuilder("tbody");
            table.InnerHtml += tBody.ToString();
            return new MvcHtmlString(table.ToString());
        }

        private static string BuildDefaultSorting(GridSettings gridSettings)
        {
            if (gridSettings.DefaultSorting.HasValues())
            {
                string sortContent = string.Empty;
                foreach (SortCriteria sortCriteria in gridSettings.DefaultSorting)
                {
                    int index = gridSettings.Columns.FindIndex(c => c.Name == sortCriteria.PropertyName);
                    if (index == -1)
                    {
                        throw new ArgumentOutOfRangeException(
                            "The column set as default sort was not found as part of the columns. Column name: " +
                            sortCriteria.PropertyName);
                    }
                    sortContent += string.Format("{0},{1}|", index,
                        sortCriteria.SortOrder == SortOrder.Ascendant ? "asc" : "desc");
                }
                sortContent = sortContent.TrimEnd('|');
                return sortContent;
            }
            return null;
        }

        private static void ReadDisplayNameFromLocalizationAttributesIfNotOverriden(GridSettings gridSettings)
        {
            Type type = gridSettings.SourceType;
            if (type == null)
                return;

            List<PropertyInfo> properties = type.GetProperties().ToList();

            foreach (ColumnSettings column in gridSettings.Columns)
            {
                if (string.IsNullOrEmpty(column.Name)) continue;
                PropertyInfo prop = properties.FirstOrDefault(p => p.Name == column.Name.Replace(".", ""));
                if (prop == null)
                {
                    continue;
                }

                var displayAttribute = prop.GetCustomAttributes(typeof(DisplayAttribute)).FirstOrDefault() as DisplayAttribute;
                if (displayAttribute != null)
                {
                    column.DisplayName = LocalisedMetadataProvider.GetLocalizedDisplayName(displayAttribute, null, prop.Name);
                }
            }
        }

        public static GridSettings SetPageSizeEnum(this GridSettings settings, PageSize pageSize = PageSize.Default)
        {
            return settings.SetPageSize(GetSize(pageSize.ToString()));
        }


        private static int GetSize(string setting)
        {
            var collection = ConfigurationManager.GetSection("gridPageSize") as NameValueCollection;
            if (collection == null) return 20;
            var entry = collection[setting] ?? collection["default"];
            int size = 0;
            if (!int.TryParse(entry, out size)) size = 20;
            return size;
        }
    }
}

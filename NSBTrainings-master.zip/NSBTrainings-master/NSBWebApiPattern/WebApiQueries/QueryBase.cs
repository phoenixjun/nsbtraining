﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using WebApiQueries.Infra;

namespace WebApiQueries
{
    public abstract class QueryBase
    {
        private readonly IUnitOfWork _context;

        protected QueryBase(IUnitOfWork context)
        {
            _context = context;
        }

        protected IQueryable<T> GetDBSet<T>() where T : EntityBase
        {
            return ((DbContext)_context).Set<T>().AsQueryable();
        }

        private IQueryable<T> Include<T>(IEnumerable<Expression<Func<T, object>>> includeProperties, IQueryable<T> query) where T : EntityBase
        {
            foreach (var property in includeProperties)
            {
                query = query.Include(property);
            }
            return query;
        }

        public virtual IQueryable<T> GetAll<T>(params Expression<Func<T, object>>[] includeProperties) where T : EntityBase
        {
            return Include(includeProperties, GetDBSet<T>());
        }

        public virtual T SingleOrDefault<T>(Expression<Func<T, bool>> predicate, params Expression<Func<T, object>>[] includeProperties) where T : EntityBase
        {
            IQueryable<T> query = GetDBSet<T>();
            query = Include(includeProperties, query);
            return query.SingleOrDefault(predicate);
        }

        public virtual T Single<T>(Expression<Func<T, bool>> predicate, params Expression<Func<T, object>>[] includeProperties) where T : EntityBase
        {
            IQueryable<T> query = GetDBSet<T>();
            query = Include(includeProperties, query);
            return query.Single(predicate);
        }

        public bool Exists<T>(Expression<Func<T, bool>> predicate) where T : EntityBase
        {
            IQueryable<T> query = GetDBSet<T>();
            return query.Any(predicate);
        }
    }
}

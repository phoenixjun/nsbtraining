﻿using System;
using WebApiQueries.QueryPattern;

namespace WebApiQueries.QueryPattern2
{
    public sealed class PricingRuleQuery : IQuery<PricingRuleQuery.Result>
    {

        public class Result
        {
        }

        public QueryResult<Result> Execute(CriteriaBase criteriaBase)
        {
            throw new NotImplementedException();
        }
    }
}

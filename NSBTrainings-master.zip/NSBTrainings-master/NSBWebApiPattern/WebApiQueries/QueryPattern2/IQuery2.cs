﻿using WebApiQueries.QueryPattern;

namespace WebApiQueries.QueryPattern2
{
    public interface IQuery<TResult>
    {
        QueryResult<TResult> Execute(CriteriaBase criteriaBase);
    }
}

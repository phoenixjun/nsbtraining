import-module WebAdministration
import-module WebAdministration

# add the ssl cert to local store if it doesn't already exist
certutil �f -p "TEST0000" �importpfx "localhost_cert.pfx"
﻿import-module WebAdministration

# ensuring required MIME type(s)

if (!(Get-WebConfigurationProperty -Filter "//staticContent/mimeMap[@fileExtension='.woff']" -PSPath IIS:\ -Name fileExtension)) {
	Add-WebConfigurationProperty //staticContent -name collection -value @{fileExtension='.woff'; mimeType='application/font-woff'}
}

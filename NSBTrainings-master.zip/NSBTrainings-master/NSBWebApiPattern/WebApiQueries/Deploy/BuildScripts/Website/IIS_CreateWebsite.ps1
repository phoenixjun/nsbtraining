Param( $Folder = '', $SiteName = '', $Port=0, $SslPort = 0, $AppPool = 'DefaultAppPool')

import-module WebAdministration

Write-Host "========================================================="
Write-Host "Create $SiteName"

# remove site if it exists
if (dir IIS:\Sites | Where {$_.Name -match $SiteName}) {
Remove-Item -recurse IIS:\Sites\$SiteName }

$basePath = Resolve-Path "..\..\$Folder"
# add the site
New-Item iis:\Sites\$SiteName -bindings @{protocol="http";bindingInformation=(":" + $Port + ":")} -physicalPath ("$basePath\")
Set-ItemProperty IIS:\Sites\$SiteName -name applicationPool -value $AppPool
New-WebBinding -Name $SiteName -IP "*" -Port $SslPort -Protocol https

Set-WebConfigurationProperty -filter /system.WebServer/security/authentication/AnonymousAuthentication -name enabled -value true -location $SiteName
Set-WebConfigurationProperty -filter /system.WebServer/security/authentication/windowsAuthentication -name enabled -value false -location $SiteName
Set-WebConfigurationProperty -filter /system.WebServer/security/authentication/basicAuthentication -name enabled -value false -location $SiteName

# add the ssl cert to IIS if it doesn't already exist
$iisBindings = dir IIS:\SslBindings | where {$_.Sites -eq $SiteName}
if ($null -eq $iisBindings -or $iisBindings.count -eq 0) {
	$cert = Get-ChildItem cert:\LocalMachine\My | where { $_.Subject -like "*LocalHost*" } | select -First 1
	$cert | New-Item IIS:\SslBindings\0.0.0.0!$SslPort  }

Write-Host "Create $SiteName Complete"


Param($AppPool = 'DefaultAppPool')
import-module WebAdministration

# See http://wiki/display/KB/Websites+-+Port+Ranges+-+Australia for appropriate ports
# NEED TO MANUALLY SET THE PORT NUMBERS FOR THE WEBSITES

.\IIS_Unlock.ps1
.\IIS_AddCertificate.ps1
.\IIS_EnsureMIMETypes.ps1

.\IIS_CreateAdminWebsite.ps1 -Folder "Travel.WebApi" -SiteName "Travel.WebApi" -Port 8200 -SslPort 8201 -AppPool $AppPool

.\IIS_CreateAdminWebsite.ps1 -Folder "Travel.Portal" -SiteName "Travel.Portal" -Port 8210 -SslPort 8211 -AppPool $AppPool

.\IIS_CreateAdminWebsite.ps1 -Folder "Travel.WebApiInternal" -SiteName "Travel.WebApiInternal" -Port 8215 -SslPort 8216 -AppPool $AppPool

import-module WebAdministration

Write-Host "Unlock //isapiFilters"

set-webconfiguration //isapiFilters machine/webroot/apphost -metadata overrideMode -value Allow
﻿$scriptpath = Split-Path -Parent -Path $MyInvocation.MyCommand.Definition
write-host "scriptpath: $scriptpath"
pushd $scriptpath

# Build Everything (LOCALLY)

write-host "Build local solution..." -foregroundcolor green
.\BuildSolution.ps1

write-host "Create database..." -foregroundcolor green
.\Database\CreateDatabase.ps1 -dbname "travel_log"
#.\Database\UpdateDatabaseToLatestVersion.ps1

#write-host "Build local database..." -foregroundcolor green
#cd Database
#.\DatabaseUpgrade.ps1 loc
#cd ..

write-host "Build local website..." -foregroundcolor green
cd Website
.\IIS_CreateWebsites.ps1 -AppPool "DefaultAppPool"
cd ..

.\SetLocalEnvironment.ps1

popd
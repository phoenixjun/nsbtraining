﻿
$envFilePath = Join-Path $env:programfiles "Pinpoint\Environment"
if (!(Test-Path -Path $envFilePath)) {
	New-Item -ItemType directory -Path $envFilePath
}

$envFilePath = Join-Path $envFilePath "loc.txt"
if (!(Test-Path -Path $envFilePath)) {
	New-Item -ItemType file -Path $envFilePath
}

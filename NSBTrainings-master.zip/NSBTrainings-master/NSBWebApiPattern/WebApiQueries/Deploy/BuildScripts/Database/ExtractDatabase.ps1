﻿# unzip sql database backup and attach to sqlserver

param(
	[Parameter(Mandatory=$true)][string]$serverName,
	[Parameter(Mandatory=$true)][string]$databaseName,
	[Parameter(Mandatory=$true)][string]$archiveFilePath
)

Set-Alias _7z "c:\program files (x86)\7-Zip\7z.exe"
if (!(Test-Path _7z))
{
	Set-Alias _7z "c:\program files\7-Zip\7z.exe"
}

$archiveFilePath = Resolve-Path $archiveFilePath
$workingFolder = [System.IO.Path]::GetDirectoryName($archiveFilePath)
Write-Host "workingFolder=$workingFolder"
$tempFolder = "$workingFolder\restore_" + [Guid]::NewGuid().ToString("n")
Write-Host "tempFolder=$tempFolder"
new-item -path $tempFolder -Type directory | Out-Null

pushd $tempFolder
_7z e $archiveFilePath | out-null
$dbBackupFile = Get-ChildItem -Path $tempFolder | Resolve-Path | Split-Path -NoQualifier
popd

Write-Host "dbBackupFile=$dbBackupFile"

$scriptPath = split-path $MyInvocation.MyCommand.Path
pushd $scriptPath
.\RestoreDatabaseToSqlServer.ps1 -serverName $serverName -databaseName $databaseName -BackupFilePath $dbBackupFile
popd

Remove-Item $tempFolder -Recurse -Force

﻿Function RefreshDatabase([string]$databaseName, [string]$fileName) {
	Write-Host "refreshing database $databaseName to $fileName"
	$newPath = [Guid]::NewGuid().ToString("n");
	new-item -path $newPath -Type directory | Out-Null
	$newPath = resolve-path "$newPath"

	osql -S $serverName -d $databaseName -E -n -Q "BACKUP DATABASE $databaseName TO DISK = '$newPath\$fileName' WITH FORMAT;"
	_7z a -t7z "$newPath\$fileName.7z" "$newPath\$fileName"
	$destPath = resolve-path "..\..\$globalsafeprojectname$.DatabaseUpgrade\Setup\Backup\$databaseName"

	# checkout the file
	tf checkout "$destPath\$fileName.7z"

	# move in replacement
	move-item "$newPath\$fileName.7z" "$destPath\$fileName.7z" -force

	remove-item $newPath -force -recurse
}

. ../Include.ps1

$serverName = ".\sql2012";

$databases = @{
	"au_customer_service_app" = "au_customer_service_app.bak";
	"au_customer_service_app_log" = "au_customer_service_app_log.bak";
}

$databases.GetEnumerator() | Foreach {
	RefreshDatabase $_.Key $_.Value
}

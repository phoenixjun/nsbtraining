﻿param ([Parameter(Mandatory=$true)]$dbname)

[System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SMO') | out-null

$srv = new-Object Microsoft.SqlServer.Management.Smo.Server("(local)")
$db = $srv.Databases[$dbname]
if ($db -eq $null)
{
    $db = New-Object Microsoft.SqlServer.Management.Smo.Database($srv, $dbname)
    $db.Create()
    Write-Host "Database $dbname created on" $db.CreateDate
}
else
{
    Write-Host "Database $dbname already exists"
}
﻿$currentPath = Get-Location
$path = (get-item $currentPath).parent.FullName
$dllPath = Join-Path $path "Travel.IntegrationTests\bin\Debug\"

$configPath = Join-Path $dllPath "Travel.IntegrationTests.dll.config"
if (!(Test-Path $configPath))
{
	Write-Host $configPath "does not exist"
	exit -1 
}
[System.AppDomain]::CurrentDomain.SetData("APP_CONFIG_FILE", $config_path)

$bytes = [System.IO.File]::ReadAllBytes($dllPath + “Travel.IntegrationTests.dll”)
[Reflection.Assembly]::Load($bytes)
$bytes = [System.IO.File]::ReadAllBytes($dllPath + “Ninject.dll”)
[Reflection.Assembly]::Load($bytes)
$bytes = [System.IO.File]::ReadAllBytes($dllPath + “Travel.Data.dll”)
[Reflection.Assembly]::Load($bytes)
$bytes = [System.IO.File]::ReadAllBytes($dllPath + “Travel.Domain.dll”)
[Reflection.Assembly]::Load($bytes)
$bytes = [System.IO.File]::ReadAllBytes($dllPath + “EntityFramework.dll”)
[Reflection.Assembly]::Load($bytes)
$bytes = [System.IO.File]::ReadAllBytes($dllPath + “Ninject.Web.Common.dll”)
[Reflection.Assembly]::Load($bytes)

$instance = New-Object Travel.IntegrationTests.Service.UpdateDatabaseToLatestVersionTests
$instance.UpdateDatabase()
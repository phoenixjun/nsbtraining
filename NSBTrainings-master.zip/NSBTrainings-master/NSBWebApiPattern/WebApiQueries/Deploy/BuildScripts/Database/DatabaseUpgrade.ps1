﻿param ([Parameter(Mandatory=$true)]$environment)

Set-Alias DatabaseUpgrade "../../$globalsafeprojectname$.DatabaseUpgrade/bin/debug/$globalsafeprojectname$.DatabaseUpgrade.exe"

Function UpgradeLocalDatabase([string] $databaseName, [string] $scriptFolderName) {
	
	$scriptFolderPath = resolve-Path "../../$globalsafeprojectname$.DatabaseUpgrade" 
	$scriptFolderPath = join-path $scriptFolderPath $scriptFolderName
	
	if (test-path $scriptFolderPath) {
		if (get-childItem $scriptFolderPath) {

			$ConnectionStrings = @{
				loc = @("Data Source=.\sql2012;Initial Catalog=$databaseName;Integrated Security=SSPI;Pooling=true;");
				uat = @("");
			}

			$connectionString = $ConnectionStrings[$environment]

			Write-Host "`nUpgrading local database $databaseName, script folder name: $scriptFolderName`n"
			DatabaseUpgrade /connectionString=""$connectionString"" /scriptFolderName=""$scriptFolderName"" /executeScriptsDirectly
		} else {
			Write-Host "No Scripts in $scriptFolderName for $databaseName"
		}
	} else {
		Write-Host "Database $databaseName not updated: Script folder $scriptFolderName does not exist" -backgroundcolor red -foregroundcolor white
	}
}

$ErrorActionPreference = 'Stop'

if (test-path 'C:\Program Files (x86)\Microsoft Visual Studio 12.0\Common7\IDE\tf.exe') {
	set-alias tf 'C:\Program Files (x86)\Microsoft Visual Studio 12.0\Common7\IDE\tf.exe'
}
else {
	set-alias tf 'C:\Program Files (x86)\Microsoft Visual Studio 8\Common7\IDE\tf.exe'
}

set-alias msbuild 'C:\Windows\Microsoft.NET\Framework\v4.0.30319\msbuild.exe'
tf get ../../$globalsafeprojectname$.DatabaseUpgrade /r
msbuild ..\..\$globalsafeprojectname$.DatabaseUpgrade\$globalsafeprojectname$.DatabaseUpgrade.csproj

.\DbUpCheck.ps1 "..\..\$globalsafeprojectname$.DatabaseUpgrade\$globalsafeprojectname$.DatabaseUpgrade.csproj"

UpgradeLocalDatabase "$globalsafeprojectname$" "Scripts"
UpgradeLocalDatabase "$globalsafeprojectname$_log" "LogScripts"

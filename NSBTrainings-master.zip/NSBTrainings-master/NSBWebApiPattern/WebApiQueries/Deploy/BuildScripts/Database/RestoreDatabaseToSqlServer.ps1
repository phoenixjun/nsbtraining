﻿# Restore a database on a server given a database backup file, database name and a server name
# Shamelessly plagiarised from http://www.codeproject.com/Articles/110908/SQL-DB-Restore-using-PowerShell#

param(
	[Parameter(Mandatory=$true)] [string] $serverName, 
	[Parameter(Mandatory=$true)] [string] $databaseName, 
	[Parameter(Mandatory=$true)] [string] $backupFilePath
)

try {
	$backupFilePath = Resolve-Path $backupFilePath

	# Load assemblies
	[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SMO") | Out-Null
	[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoExtended") | Out-Null
	[Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.ConnectionInfo") | Out-Null
	[Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoEnum") | Out-Null

	# Create sql server object
	$server = New-Object ("Microsoft.SqlServer.Management.Smo.Server") $serverName

	# Create restore object and specify its settings
	$smoRestore = new-object ("Microsoft.SqlServer.Management.Smo.Restore")
	$smoRestore.Database = $databaseName
	$smoRestore.NoRecovery = $false;
	$smoRestore.ReplaceDatabase = $true;
	$smoRestore.Action = "Database"

	# Create location to restore from
	$backupDevice = New-Object ("Microsoft.SqlServer.Management.Smo.BackupDeviceItem") ($backupFilePath, "File")
	$smoRestore.Devices.Add($backupDevice)

	# Give empty string a nice name
	$empty = ""

	# there may be multiple data files so create multiple restore objects

	# Get the file list from backup file
	$dbFileList = $smoRestore.ReadFileList($server)

	# Specify new data files
	$i = 0
	$dbFileList.Select("Type = 'D'") | Foreach {
		$i++
		$smoRestoreDataFile = New-Object ("Microsoft.SqlServer.Management.Smo.RelocateFile")
		$defaultData = $server.DefaultFile
		if (($defaultData -eq $null) -or ($defaultData -eq $empty))
		{
		    $defaultData = $server.Information.MasterDBPath
		}
		$smoRestoreDataFile.LogicalFileName = $_.LogicalName
		$smoRestoreDataFile.PhysicalFileName = Join-Path -Path $defaultData -ChildPath ($databaseName + "_" + $i + "_Data.mdf")
		$smoRestore.RelocateFiles.Add($smoRestoreDataFile) | Out-Null
	}
	
	# Specify new log files
	$i = 0
	$dbFileList.Select("Type = 'L'") | Foreach {
		$i++
		$smoRestoreLogFile = New-Object ("Microsoft.SqlServer.Management.Smo.RelocateFile")
		$defaultLog = $server.DefaultFile
		if (($defaultLog -eq $null) -or ($defaultLog -eq $empty))
		{
		    $defaultLog = $server.Information.MasterDBLogPath
		}
		$smoRestoreLogFile.LogicalFileName = $_.LogicalName
		$smoRestoreLogFile.PhysicalFileName = Join-Path -Path $defaultLog -ChildPath ($databaseName + "_" + $i + "_Log.mdf")
		$smoRestore.RelocateFiles.Add($smoRestoreLogFile) | Out-Null
	}	
	
	# Specify new Full Text files
	$i = 0
	$dbFileList.Select("Type = 'F'") | Foreach {
		$i++
		$smoRestoreFTFile = New-Object ("Microsoft.SqlServer.Management.Smo.RelocateFile")
		$defaultFT = $server.DefaultFile
		if (($defaultFT -eq $null) -or ($defaultFT -eq $empty))
		{
		    $defaultFT = $server.Information.MasterDBPath
		}
		$smoRestoreFTFile.LogicalFileName = $_.LogicalName
		$smoRestoreFTFile.PhysicalFileName = Join-Path -Path $defaultFT -ChildPath ($databaseName + "_" + $i + "_FT")
		$smoRestore.RelocateFiles.Add($smoRestoreFTFile) | Out-Null
	}	
	
	# Kill any existing connections and drop the database
	if ($server.Databases.Contains($databaseName)) {
		$server.KillAllProcesses($databaseName)
		$server.Databases[$databaseName].drop()
	}
	# Restore the database
	$smoRestore.SqlRestore($server)
} catch [Exception] {
	"Database restore failed:`n`n " + $_.Exception
}

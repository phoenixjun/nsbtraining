﻿# Check if there are scripts in a dbup project that are not set as embeddedresources

Param(
	[parameter(mandatory=$true)]
	[string]$filename
)

[xml]$xmldoc = Get-Content $filename
$allItemGroup = $xmldoc.Project.ItemGroup | foreach { $_.ChildNodes }

$problemItems = $allItemGroup | where { 
	$_.Name -ne "EmbeddedResource" -and 
	$_.Include -like "*.sql" -and 
	$_.Include -notlike "Setup\*"
}

if ($problemItems) {
	Write-Host "WARNING! There are dbup scripts in this project that are not EmbeddedResources!" -ForegroundColor White -BackgroundColor Red
	Write-Host "Project File: "(Resolve-Path $filename) -ForegroundColor White -BackgroundColor Red
	Write-Host 

	foreach ($item in $problemItems) {
		Write-Host $item.Name $item.Include  -ForegroundColor White -BackgroundColor Red
	}
}

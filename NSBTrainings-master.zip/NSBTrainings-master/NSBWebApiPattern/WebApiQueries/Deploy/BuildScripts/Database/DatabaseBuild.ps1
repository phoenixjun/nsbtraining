﻿# unzip sql database backup and attach to sqlserver

Param(
	$Env,
	$Database,
	$ServerName,
	$DatabaseProjectFolder
)

Write-Host ""
Write-Host "Build Database ($Database) - $Env .." -foregroundcolor green
Write-Host "Params: `n Env: $Env `n Database: $Database `n Server Name: $ServerName `n Database Project Folder: $DatabaseProjectFolder" -foregroundcolor yellow
Write-Host ""

Function ExecuteDeploymentScript([string]$serverName, [string]$databaseName, [string]$scriptPath){
	if (test-path "c:\program files (x86)\microsoft sql server\100\tools\binn\OSQL.EXE") {
		Set-Alias osql "c:\program files (x86)\microsoft sql server\100\tools\binn\OSQL.EXE"
	} elseif (test-path "c:\program files (x86)\microsoft sql server\90\tools\binn\OSQL.EXE") {
		Set-Alias osql "c:\program files (x86)\microsoft sql server\90\tools\binn\OSQL.EXE"
	}
	
	$inputfile = [System.IO.Path]::GetTempFileName()
	write-host "inputfile name: $inputfile"
	get-content $scriptPath | set-content $inputfile -Encoding UNICODE

	$shortPath = ".\" + ($scriptPath.Split("\")[-2..-1] -join "\")
	Write-Host "Executing deployment script $shortPath on $serverName.$databaseName"
	$outputfile = [System.IO.Path]::GetTempFileName()
	osql -S $serverName -d $databaseName -E -n -i $inputfile -o $outputfile
	$sqlerrors = (Get-Content $outputfile) -match "Msg.+([0-9]+).+Level.+([0-9]+).+state"
	if ($sqlerrors) {
		foreach ($line in Get-Content $outputfile ) {
			if ($line -match "Msg.+([0-9]+).+Level.+([0-9]+).+state") {
				Write-Host $line -ForegroundColor White -BackgroundColor Red
			}else{
				Write-Host $line
			}
		}
	}
	Remove-Item -Path $outputfile -Force -ErrorAction SilentlyContinue
	Remove-Item -Path $inputfile -Force -ErrorAction SilentlyContinue
}

Set-Alias _7z "c:\program files\7-Zip\7z.exe"

Write-Host "Execute PRE deployment scripts for database: $Database..."
#ExecuteDeploymentScript ".\sql2012" "$Database" "$DatabaseProjectFolder\Setup\Backup\$Database\PreDeployScript\something.sql"

Write-Host "Unzip database backup for database: $Database..."
$archiveFilePath = Resolve-Path "$DatabaseProjectFolder\Setup\Backup\$Database\$Database.bak.7z"
$workingFolder = [System.IO.Path]::GetDirectoryName($archiveFilePath)
$tempFolder = "$workingFolder\restore_" + [Guid]::NewGuid().ToString("n")
New-Item -path $tempFolder -Type directory | Out-Null

pushd $tempFolder
_7z e $archiveFilePath | out-null
$dbBackupFile = Get-ChildItem -Path $tempFolder | Resolve-Path | Split-Path -NoQualifier

Write-Host "Unzip database backup for database: $Database...done"

popd
	
Write-Host "Restore database backup for database: $Database..."
.\Database\RestoreDatabaseToSqlServer.ps1 -serverName $ServerName -databaseName $Database -BackupFilePath $dbBackupFile
Remove-Item $tempFolder -Recurse -Force
Write-Host "Restore database backup for database: $Database...done"

Write-Host "Execute POST deployment scripts for database: $Database..."
ExecuteDeploymentScript $ServerName $Database "$DatabaseProjectFolder\Setup\Script\set_trustworthy.sql"

$postDeploymentFolder = "$DatabaseProjectFolder\Setup\Backup\$Database\PostDeployScript"
if (test-path -path $postDeploymentFolder) {
	Get-ChildItem -Path $postDeploymentFolder -Filter *.sql | Foreach-Object {
		ExecuteDeploymentScript $ServerName $Database ($_.FullName)
	}
}

Write-Host "Execute POST deployment scripts for database: $Database...done"
Write-Host ""

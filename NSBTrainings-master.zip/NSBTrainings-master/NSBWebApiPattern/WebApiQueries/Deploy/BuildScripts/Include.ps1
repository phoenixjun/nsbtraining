﻿set-alias tf "c:\program files (x86)\microsoft visual studio 12.0\common7\ide\TF.exe"
set-alias msbld "$env:windir\Microsoft.NET\Framework\v4.0.30319\MSBuild.exe"
set-alias _7z "c:\program files\7-zip\7z.exe"

if (test-path "c:\program files (x86)\microsoft sql server\100\tools\binn\OSQL.EXE") {
	Set-Alias osql "c:\program files (x86)\microsoft sql server\100\tools\binn\OSQL.EXE"
} elseif (test-path "c:\program files (x86)\microsoft sql server\90\tools\binn\OSQL.EXE") {
	Set-Alias osql "c:\program files (x86)\microsoft sql server\90\tools\binn\OSQL.EXE"
}

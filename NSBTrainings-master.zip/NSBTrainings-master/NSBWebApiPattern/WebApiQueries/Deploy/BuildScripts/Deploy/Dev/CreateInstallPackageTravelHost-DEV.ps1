﻿cls
#$deployFolder = "\\au.pp.net\ppapps\TravelNSBHost"
$deployFolder = "\\fsprod08v\imgroups\Im Shared\database modules\Deploy\Atlas\2015 September Release\NSB\TravelNSBHost"
#$deployFolder = "c:\temp\NSB\TravelNSBHost"
$scriptLocation = [System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Path)

pushd $scriptLocation
..\Common\CreateInstallPackageNServiceBusHost.ps1 							`
	-environment               dev											`
    -versionUpgrade            $true										`
    -serviceName               "Travel.Host.NServiceBus"	`
    -projectName               Travel.Host         `
    -projectFileName           Travel.Host         `
    -deployFolder              $deployFolder                                `
    -displayName               "Atlas Travel NServiceBus Host"   `
    -description               "Atlas Travel NServiceBus Host"   `
    -endpointConfigurationType "Travel.Host.EndpointConfig, Travel.Host"

popd



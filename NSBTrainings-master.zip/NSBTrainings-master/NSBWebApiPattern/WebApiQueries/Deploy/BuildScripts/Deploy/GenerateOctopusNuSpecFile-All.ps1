﻿.\GenerateOctopusNuSpecFile-Travel.Portal.ps1 "Travel.Portal" "sso-travel-au" "sso-travel-au.1.0.0.nuspec"
.\GenerateOctopusNuSpecFile-Travel.WebApi.ps1 "Travel.WebApi" "travelapi-au" "travelapi-au.1.0.0.nuspec"
.\GenerateOctopusNuSpecFile-Travel.WebApi.ps1 "Travel.WebApiInternal" "travelinternalapi-au" "travelinternalapi-au.1.0.0.nuspec"
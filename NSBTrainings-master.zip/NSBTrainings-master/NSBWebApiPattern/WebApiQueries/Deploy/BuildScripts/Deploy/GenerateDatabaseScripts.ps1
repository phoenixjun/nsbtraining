﻿# Work in progress, do not use // SimonN

param([string]$Environment)

switch ($Environment)
{
	dev
	{
		$membershipConn = 			"Data Source=AUSQLDEVSCL25\CMN;Initial Catalog=au_travel_services;Integrated Security=SSPI;Pooling=true;"
		$membershipLoggingConn = 	"Data Source=AUSQLDEVSCL25\CMN;Initial Catalog=au_travel_services_log;Integrated Security=SSPI;Pooling=true;"
	}
	stg
	{
		$membershipConn = 			"Data Source=AUSQLSTGSCL25\CMN;Initial Catalog=au_travel_services;Integrated Security=SSPI;Pooling=true;"
		$membershipLoggingConn = 	"Data Source=AUSQLSTGSCL25\CMN;Initial Catalog=au_travel_services_log;Integrated Security=SSPI;Pooling=true;"
	}
	mtf
	{
		$membershipConn = 			"Data Source=(local)\SQL2012;Initial Catalog=au_travel_services;Integrated Security=SSPI;Pooling=true;"
		$membershipLoggingConn = 	"Data Source=(local)\SQL2012;Initial Catalog=au_travel_services_log;Integrated Security=SSPI;Pooling=true;"
	}
	pro
	{
		$membershipConn = 			"Data Source=(local)\SQL2012;Initial Catalog=au_travel_services;Integrated Security=SSPI;Pooling=true;"
		$membershipLoggingConn = 	"Data Source=(local)\SQL20121;Initial Catalog=au_travel_services_log;Integrated Security=SSPI;Pooling=true;"
	}
	default 
	{
		Write-Error "Unrecognized target database to execute against"
		exit -1;
	}
}

$currDate = Get-Date -format yyyy-MM-dd

#	Update-Database -ConnectionString "dev.TravelContext" -ConnectionProviderName "System.Data.SqlClient" -Script
Update-Database -ConnectionString "server=AUSQLDEVSCL25\CMN;database=au_travel_services;trusted_connection=true;MultipleActiveResultSets=True;" -ConnectionProviderName "System.Data.SqlClient" -Script
#Update-Database -ConnectionProviderName "System.Data.SqlClient" -Script

#Update-Database -Script -SourceMigration:0
#Update-Database -Script -SourceMigration: $InitialDatabase -TargetMigration: AddPostAbstract

#& "..\..\Membership.DatabaseUpgrade\bin\Debug\Membership.DatabaseUpgrade.exe" /connectionString=$membershipConn /scriptFolderName="MembershipScripts"
#.\richcopy_sql.cmd "C:\Users\$env:username\Desktop\DatabaseUpgrade - $currDate\.MembershipScripts\" "\\fsprod08v\imgroups\Im Shared\database modules\Deploy\Atlas\2015 September Release\Membership\$Environment - $currDate\MembershipScripts"
#& "..\..\Membership.DatabaseUpgrade\bin\Debug\Membership.DatabaseUpgrade.exe" /connectionString=$membershipLoggingConn /scriptFolderName="MembershipLogScripts"
#.\richcopy_sql.cmd "C:\Users\$env:username\Desktop\DatabaseUpgrade - $currDate\.MembershipLogScripts\" "\\fsprod08v\imgroups\Im Shared\database modules\Deploy\Atlas\2015 September Release\Membership\$Environment - $currDate\MembershipLogScripts"

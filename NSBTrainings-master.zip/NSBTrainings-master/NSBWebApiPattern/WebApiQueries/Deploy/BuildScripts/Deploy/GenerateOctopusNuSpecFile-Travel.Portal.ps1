﻿Param($projectName = "Travel.Portal", $iisSiteName = "sso-travel-au", $nuspecFileName = "sso-travel-au.1.0.0.nuspec", $branch = "2015 September Release - Atlas", $solutionName = "Travel")

set-alias msbld "${Env:WinDir}\Microsoft.NET\Framework\v4.0.30319\MSBuild.exe"

Function GetFiles($path) 
{ 
    foreach ($item in Get-ChildItem $path -Recurse -include *.cer, *.pfx, *.asax, *.pdb, *.dll, *.aspx,*.ascx,*.svc,*.config,*.asmx", ".dll", ".ini,*.txt,*.js,*.css,*.gif,*.jpg,*.png,*.htm,*.html,*.xsl,*.xml,*.swf,*.lic,*.cshtml -exclude *nsb_log*, Project_Readme.html, *TempPE*, *.csproj*) 
    {
		$relativeFilePath = resolve-Path -Relative $item

		$relativeFilePath = $relativeFilePath.replace("..\","")
		$relativeFilePath = $relativeFilePath.replace("..\","")
		$relativeFilePath = $relativeFilePath.replace("$projectName\","")
		
		if(-Not ($relativeFilePath -like '*obj\*')) {
			$XmlWriter.WriteStartElement('file')
			$XmlWriter.WriteAttributeString('src', $relativeFilePath)
			$XmlWriter.WriteAttributeString('target', "$iisSiteName\$relativeFilePath")
			$xmlWriter.WriteEndElement()
		}
    }
}

Function CleanDebugFolder($path) { 
$debugFolder = "$path\bin" 

Remove-Item "$debugFolder\*" -recurse 
}


$path = resolve-Path "../../$projectName"

CleanDebugFolder($path)

$solutionPath = resolve-Path "../../../../$branch"
Write-host "Rebuild local solution... $solutionPath" -foregroundcolor green
msbld "$solutionPath\$solutionName.sln" /noconsolelogger /p:Configuration="Debug" /m /t:rebuild

$xmlFile = "$path\$nuspecFileName"

$xmlEncoding = [System.Text.Encoding]::UTF8

$XmlWriter = New-Object System.XMl.XmlTextWriter($xmlFile,$xmlEncoding)

$xmlWriter.Formatting = 'Indented'
$xmlWriter.Indentation = 1
$XmlWriter.IndentChar = "`t"

$xmlWriter.WriteStartDocument()

$xmlWriter.WriteStartElement('package')
$XmlWriter.WriteAttributeString('xmlns', 'http://schemas.microsoft.com/packaging/2010/07/nuspec.xsd')

$xmlWriter.WriteStartElement('metadata')
$XmlWriter.WriteElementString('id', $iisSiteName)
$XmlWriter.WriteElementString('version', '1.0.0')
$XmlWriter.WriteElementString('authors', [Environment]::UserName)
$XmlWriter.WriteElementString('requireLicenseAcceptance', 'false')
$XmlWriter.WriteElementString('description', 'description')
$xmlWriter.WriteEndElement() #metadata

$xmlWriter.WriteStartElement('files')
GetFiles($path)
$xmlWriter.WriteEndElement() #files

$xmlWriter.WriteEndElement() #package


$xmlWriter.Flush()
$xmlWriter.Close()



﻿param(
    [Parameter(Mandatory=$true)] [string]$sourcePath,
    [Parameter(Mandatory=$true)] [string]$targetPath,
	[Parameter(Mandatory=$true)] [string]$environment
)

if (!(Test-Path -path $targetPath)) { New-Item $targetPath -Type Directory }

$workerFile = "$targetPath\App.worker.config"
$distributorFile = "$targetPath\App.distributor.config"

$sourcePath = join-path -Path $sourcePath "Configuration"

Copy-Item "$sourcePath\$environment.worker.config" $workerFile
Copy-Item "$sourcePath\$environment.distributor.config" $distributorFile

popd

﻿Param(
	[Parameter(Mandatory=$true)] [string]$environment,
	[Parameter(Mandatory=$true)] [string]$versionUpgrade,
	[Parameter(Mandatory=$true)] [string]$serviceName,
	[Parameter(Mandatory=$true)] [string]$projectName,
	[Parameter(Mandatory=$true)] [string]$projectFileName,
	[Parameter(Mandatory=$true)] [string]$deployFolder,
	[Parameter(Mandatory=$true)] [string]$displayName,
	[Parameter(Mandatory=$true)] [string]$description,
	[Parameter(Mandatory=$true)] [string]$endpointConfigurationType
)


function CreateBatchFile([string]$hostType, [string]$serviceName, [string]$batchFolder, [string]$versionFullName, [string]$installFolder, [string]$serviceBinFolder, [string]$configFolder, [string]$configFileName, [string]$executeFolder) {
	$hostType = $hostType.Trim();
	if ($hostType -notmatch "(Distributor|Worker)") {
		Write-Error "Unknown host type $hostType.  Expecting Distributor or Worker"
		return
	}
	
	$serviceName = $serviceName + "." + $hostType
    $batchFile = join-path $batchFolder "$hostType.$versionFullName.bat"
	$deployFolder = "C:\Program Files\Pinpoint\$serviceName"

	$deploymentOption = "NServiceBus.MSMQ$hostType"
	if($hosttype -match "(Worker)")
	{
		$deploymentOption = " NServiceBus.Production " + $deploymentOption
	}
	if ($hostType -match "(Distributor)") 
	{
		$deploymentOption = " NServiceBus.Production " + $deploymentOption
	}



	
	$displayName = "$displayName $hostType"
	$description = "$description $hostType"
	
	Write-Host "Batch File:     $batchFile"
	Write-Host "Install Folder: $installFolder"
	Write-Host "Deploy Folder:  $deployFolder"
	Write-Host "Execute Folder: $executeFolder"

	if (!(Test-Path -path $installFolder)) { New-Item $installFolder -Type Directory }
	copy-item "$serviceBinFolder\*.exe" $installFolder -force -recurse
	copy-item "$serviceBinFolder\*.exe.config" $installFolder -force -recurse	
	copy-item "$serviceBinFolder\*.dll" $installFolder -force -recurse
	copy-item "$serviceBinFolder\*.xml" $installFolder -force -recurse
	
	copy-item "$configFileName" "$installFolder\Travel.Host.dll.config" -force -recurse

	$workerNetStart = ''
	
	$configCopyCommand = ''
	
	Write-Host "Config Folder: $configFolder"

	if ($hostType -match "(Worker)") 
	{
		$workerNetStart = 'net start "' + $serviceName + '"'		
		$configCopyCommand = 'xcopy /y "' + $configFolder + '\App.worker.config" "' + $deployFolder + '\Travel.Host.dll.config"'
	}
	if ($hostType -match "(Distributor)") 
	{
		$configCopyCommand = 'xcopy /y "' + $configFolder + '\App.distributor.config" "' + $deployFolder + '\Travel.Host.dll.config"'
	}

	$batchFileContent = '
@echo off
ECHO INSTALLING ' + $hostType.ToUpper() + '
net stop "' + $serviceName + '"
"' + $deployFolder + '\NServiceBus.Host.exe" /uninstall /serviceName:"' + $serviceName + '"
xcopy /y /f /e "' + $executeFolder + '" "' + $deployFolder + '\"
' + $configCopyCommand + '
"' + $deployFolder + '\NServiceBus.Host.exe" /install /serviceName:"' + $serviceName + '" /displayName:"' + $displayName  + '" /description:"' + $description + '"' + $deploymentOption + '
echo CHANGE SERVICE LOGIN AND PASSWORD FOR "' + $serviceName + '" BEFORE CONTINUING
PAUSE
' + $workerNetStart + '
if %errorlevel%==0 goto end
PAUSE
:end
'

	if (!(Test-Path -path $batchFolder)) {New-Item $batchFolder -Type Directory}
	$batchFileObject = New-Item -ItemType file $batchFile
	add-content $batchFileObject $batchFileContent
}

$okResponse = "1", "yes", "y", "true", "$true"
$isVersionUpgrade = $okResponse -contains $versionUpgrade
if ($isVersionUpgrade) {
	"Deploying app with version number update"
} else {
	"Deploying app without version number update"
}

set-alias msbld "$env:windir\Microsoft.NET\Framework\v4.0.30319\MSBuild.exe"

Write-Host "Environment = $environment"

$currentPath = Get-Location
$env:SolutionDir = (get-item $currentPath).parent.parent.parent.FullName

if ($environment -eq "uat") 
{
	$envDeployFolder = join-path $deployFolder "UAT"
	$buildConfiguration = "Debug"
	$envExecuteFolder = join-path $deployFolder "UAT"
}
elseif ($environment -eq "live" -or $environment -eq "prod") 
{
	$envDeployFolder = join-path $deployFolder "LIVE-STAGING"
	$buildConfiguration = "Debug"
	$environment = "live"
	$envExecuteFolder = join-path $deployFolder "Live"
}
elseif ($environment -eq "dev") 
{
	$envDeployFolder = join-path $deployFolder "DEV"
	$buildConfiguration = "Debug"
	$envExecuteFolder = join-path $deployFolder "DEV"
}
elseif ($environment -eq "stg") 
{
	$envDeployFolder = join-path $deployFolder "STG"
	$buildConfiguration = "Debug"
	$envExecuteFolder = join-path $deployFolder "STG"
}
elseif ($environment -eq "mtf") 
{
	$envDeployFolder = join-path $deployFolder "MTF"
	$buildConfiguration = "Debug"
	$envExecuteFolder = join-path $deployFolder "MTF"
}

if ($envDeployFolder.length -gt 0)
{
	$serviceProjectFolder = join-path $env:SolutionDir $projectName
	$serviceProjectFile = join-path $serviceProjectFolder "$projectFileName.csproj"

	if ($isVersionUpgrade)
	{
		Write-Host $currentPath
		$assemblyInfoFile = join-path $serviceProjectFolder "Properties\AssemblyInfo.cs"
		..\Common\UpdateVersion.ps1 $assemblyInfoFile
	}

	msbld "$serviceProjectFile" /t:rebuild /p:Configuration=$buildConfiguration

	$serviceBinFolder = join-path $serviceProjectFolder ("bin\" + $buildConfiguration)
	$serviceExeFile = join-path $serviceBinFolder "$projectFileName.dll"
	
	$versionNumber = [Reflection.AssemblyName]::GetAssemblyName($serviceExeFile).Version.ToString()
	$versionPath = (Get-Location) -split "\\"
	$versionProject = $serviceName + " - " + $versionPath[-4]
	$versionFullName = "$versionProject - Build $versionNumber"


	$batchFolder = join-path $envDeployFolder "Batch"

	$installFolder = join-path $envDeployFolder ("Install\" + $versionFullName)
	$executeFolder = join-path $envExecuteFolder ("Install\" + $versionFullName)
	$configFolder = join-path $envExecuteFolder ("Config\" + $versionFullName)
	$configFolderSrc = join-path $envDeployFolder ("Config\" + $versionFullName)
	$configFileName = "$serviceProjectFolder\app.config"
	 
	CreateBatchFile "Distributor" $serviceName $batchFolder $versionFullName $installFolder $serviceBinFolder $configFolder $configFileName $executeFolder
	CreateBatchFile "Worker" $serviceName $batchFolder $versionFullName $installFolder $serviceBinFolder $configFolder $configFileName $executeFolder

	#copy configuration files
	..\Common\CopyNSBConfigutation.ps1 -environment $environment -sourcePath $serviceProjectFolder -targetPath $configFolderSrc 

} 
else
{
	Write-Host "Unrecognised environment, deployment not run"
}

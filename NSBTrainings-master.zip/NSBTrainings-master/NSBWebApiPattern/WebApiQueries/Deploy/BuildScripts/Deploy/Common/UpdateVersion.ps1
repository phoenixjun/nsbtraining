﻿param([string]$AssemblyFile)

set-alias tf "$env:ProgramFiles (x86)\Microsoft Visual Studio 11.0\Common7\IDE\tf.exe"

if (Test-Path $AssemblyFile) {
	tf checkout $AssemblyFile
	
	$file = [IO.File]::ReadAllText("$AssemblyFile")
	
	$file -match "\[assembly: AssemblyVersion\(`"(.*)\.(.*)`"\)\]"
	
	$majorVersion = $matches[1]
	$minorVersion = [int] $matches[2]
	
	# new versions
	$newMinorVersion = $minorVersion + 1
	$newVersion = $majorVersion + "." + $newMinorVersion
	$newDate = 	Get-Date -Format "d MMMM yyyy"
	
	Write-Host "majorVersion : $majorVersion, newVersion : $newVersion, newMinorVersion : $newMinorVersion, newDate: $newDate"
	
	$file = $file -replace "\[assembly: AssemblyVersion\(`"[0-9.]+`"\)\]", "[assembly: AssemblyVersion(`"$newVersion`")]";
	$file = $file -replace "\[assembly: AssemblyFileVersion\(`"[0-9.]+`"\)\]", "[assembly: AssemblyFileVersion(`"$newVersion`")]";
	$file = $file -replace "\[assembly: AssemblyVersionDate\(`"[^`"]*`"\)\]", "[assembly: AssemblyVersionDate(`"$newDate`")]";
	$file = $file -replace "(\[assembly: AssemblyVersionComment\(`"[^`"]* - Build) [0-9]*(`"\)\])", "`$1 $newMinorVersion`$2";
	
	$file | Out-File $AssemblyFile
	
	#tf checkin $AssemblyFile /comment:"new version $newVersion" /noprompt
}
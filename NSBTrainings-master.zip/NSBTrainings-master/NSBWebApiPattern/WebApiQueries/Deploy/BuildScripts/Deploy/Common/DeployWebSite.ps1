param(
    [Parameter(Mandatory=$true)] [string]$source_path,
    [Parameter(Mandatory=$true)] [string]$target_path,
	[Parameter(Mandatory=$true)] [string]$webconfig,
    [Parameter(Mandatory=$false)] [bool]$codeOnly
)

$script_path = split-path $MyInvocation.MyCommand.Path
pushd $script_path

if (!(Test-Path -Path $target_path)) {
	New-Item -ItemType directory -Path $target_path
}

$source_path = resolve-path $source_path | Convert-Path
$target_path = resolve-path $target_path | Convert-Path

if ($codeOnly -ne $true) {
	write-host "Deploy all files..."
	.\richcopy.cmd $source_path $target_path
}
else {
	write-host "Deploy code only files..."
	$siteFolders = @("bin", "views")
	foreach ($siteFolder in $siteFolders) {
		$source_folder = join-path $source_path $siteFolder
		$target_folder = join-path $target_path $siteFolder
		write-host "Copy From: " $source_folder
		write-host "Copy To: " $target_folder
		.\richcopy.cmd $source_folder $target_folder
	}
}

$do_not_deploy = "w3c", "obj", "Properties", "aspnet_client","bin\*.pdb", "*.csproj.*"
foreach($item in $do_not_deploy){
	Remove-Item "$target_path\$do_not_deploy" -Force -Recurse -ErrorAction SilentlyContinue
}

$do_not_deploy = "obj", "Properties", "aspnet_client","bin\*.pdb", "*.csproj.*"
foreach($item in $do_not_deploy){
	Remove-Item "$target_path-parent\$do_not_deploy" -Force -Recurse -ErrorAction SilentlyContinue
}

Remove-Item "$target_path\web*.config" -Exclude $webconfig -Force -ErrorAction SilentlyContinue
Rename-Item "$target_path\$webconfig" "$target_path\web.config"

popd

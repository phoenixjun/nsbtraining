﻿Param($buildConfig = "Debug")

$scriptLocation = [System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Path)

pushd $scriptLocation

. ./Include.ps1

# get latest code
tf get "..\" /recursive

$path = Split-Path $MyInvocation.MyCommand.Path
$path = $path -replace "\\$globalsafeprojectname$.BuildTools", ""
$path = $path.trimend("$globalsafeprojectname$")
msbld "$path\$globalsafeprojectname$.sln" /noconsolelogger /p:Configuration="$buildConfig"

popd

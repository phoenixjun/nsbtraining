﻿# unzip sql database backup and attach to sqlserver

Function ExecuteDeploymentScript([string]$serverName, [string]$databaseName, [string]$scriptPath){
	if (test-path "c:\program files (x86)\microsoft sql server\100\tools\binn\OSQL.EXE") {
		Set-Alias osql "c:\program files (x86)\microsoft sql server\100\tools\binn\OSQL.EXE"
	} elseif (test-path "c:\program files (x86)\microsoft sql server\90\tools\binn\OSQL.EXE") {
		Set-Alias osql "c:\program files (x86)\microsoft sql server\90\tools\binn\OSQL.EXE"
	}
	
	$inputfile = [System.IO.Path]::GetTempFileName()
	write-host "inputfile name: $inputfile"
	get-content $scriptPath | set-content $inputfile -Encoding UNICODE

	$shortPath = ".\" + ($scriptPath.Split("\")[-2..-1] -join "\")
	Write-Host "Executing deployment script $shortPath on $serverName.$databaseName"
	$outputfile = [System.IO.Path]::GetTempFileName()
	osql -S $serverName -d $databaseName -E -n -i $inputfile -o $outputfile
	$sqlerrors = (Get-Content $outputfile) -match "Msg.+([0-9]+).+Level.+([0-9]+).+state"
	if ($sqlerrors) {
		foreach ($line in Get-Content $outputfile ) {
			if ($line -match "Msg.+([0-9]+).+Level.+([0-9]+).+state") {
				Write-Host $line -ForegroundColor White -BackgroundColor Red
			}else{
				Write-Host $line
			}
		}
	}
	Remove-Item -Path $outputfile -Force -ErrorAction SilentlyContinue
	Remove-Item -Path $inputfile -Force -ErrorAction SilentlyContinue
}

$serverName = ".\sql2012"

Set-Alias _7z "c:\program files\7-Zip\7z.exe"

$databases = @(
	"au_customer_service_app",
	"au_customer_service_app_log"
)

$databases.GetEnumerator() | Foreach {
	
	$databaseName = $_

	Write-Host "Execute PRE deployment scripts for database: $databaseName..."

	#ExecuteDeploymentScript ".\sql2012" "$databaseName" "..\..\Case.DatabaseUpgrade\Setup\Backup\$databaseName\PreDeployScript\something.sql"

	Write-Host "Execute PRE deployment scripts for database: $databaseName...done"

	Write-Host "Unzip database backup for database: $databaseName..."

	$scriptPath = split-path $PSCommandPath
	pushd $scriptPath

	$archiveFilePath = Resolve-Path "..\..\Case.DatabaseUpgrade\Setup\Backup\$databaseName\$databaseName.bak.7z"
	$workingFolder = [System.IO.Path]::GetDirectoryName($archiveFilePath)
	$tempFolder = "$workingFolder\restore_" + [Guid]::NewGuid().ToString("n")

	new-item -path $tempFolder -Type directory | Out-Null

	pushd $tempFolder
	_7z e $archiveFilePath | out-null
	$dbBackupFile = Get-ChildItem -Path $tempFolder | Resolve-Path | Split-Path -NoQualifier

	Write-Host "Unzip database backup for database: $databaseName...done"

	Write-Host "Restore database backup for database: $databaseName..."

	popd
	$scriptPath = split-path $PSCommandPath
	pushd $scriptPath

	.\RestoreDatabaseToSqlServer.ps1 -serverName $serverName -databaseName $databaseName -BackupFilePath $dbBackupFile
	Remove-Item $tempFolder -Recurse -Force

	Write-Host "Restore database backup for database: $databaseName...done"

	Write-Host "Execute POST deployment scripts for database: $databaseName..."

	ExecuteDeploymentScript $serverName $databaseName "..\..\Case.DatabaseUpgrade\Setup\Script\set_trustworthy.sql"

	$postDeploymentFolder = "..\..\Case.DatabaseUpgrade\Setup\Backup\$databaseName\PostDeployScript"
	if (test-path -path $postDeploymentFolder) {
		Get-ChildItem -Path $postDeploymentFolder -Filter *.sql | Foreach-Object {
			ExecuteDeploymentScript $serverName $databaseName ($_.FullName)
		}
	}

	Write-Host "Execute POST deployment scripts for database: $databaseName...done"

	Write-Host ""
}

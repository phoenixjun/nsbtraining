﻿
namespace WebApiQueries.Infra
{
    public interface IUnitOfWork
    {
    }
}

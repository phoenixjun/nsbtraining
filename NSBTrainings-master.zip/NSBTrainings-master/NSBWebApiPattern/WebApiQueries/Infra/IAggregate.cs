﻿using System.Collections;

namespace ASF.Domain.Infrastructure
{
    public interface IAggregate
    {
        void ApplyEvent(object e);
        ICollection GetUncommittedEvents();
        void ClearUncommittedEvents();
    }
}

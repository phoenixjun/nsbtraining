﻿using WebApiQueries.QueryPattern;

namespace ASF.Domain.Infrastructure
{
    public interface IQuery<TResult>
    {
        QueryResult<TResult> Execute(CriteriaBase context);
    }

    public sealed class QueryResult<TResult>
    {
        public TResult[] Results { get; set; }
        public int TotalFound { get; set; }
        public int PageIndex { get; set; }
        public int PageSize { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using Pinpoint.DataTableWrapper.Criterias;
using Pinpoint.DataTableWrapper.DataTables.Columns;

namespace Pinpoint.DataTableWrapper.DataTables
{
    public class GridSettings
    {
        private GridSettings()
        {
            Columns = new List<ColumnSettings>();
        }

        public string GridId { get; set; }
        public string SearchFormId { get; set; }
        public int PageSize { get; set; }
        public List<ColumnSettings> Columns { get; set; }
        public string DataSourceUrl { get; set; }
        public Type SourceType { get; set; }
        public List<SortCriteria> DefaultSorting { get; set; }
        public string DeferLoading { get; set; }

        public static GridSettings DefaultOf<T>()
        {
            var gridSettings = new GridSettings();
            gridSettings.GridId = "dataTable";
            gridSettings.PageSize = 20;
            gridSettings.SearchFormId = "search-criteria";
            gridSettings.SourceType = typeof (T);
            gridSettings.DeferLoading = "0";
            return gridSettings;
        }

        public GridSettings AddNewColumn(ColumnSettings column)
        {
            Columns.Add(column);
            return this;
        }

        public GridSettings AddNewColumn(string name, bool sortable = true, string width = null,
            string displayName = null, bool? visible = null)
        {
            var column = new ColumnSettings
            {
                Name = name,
                DisplayName = displayName,
                Width = width,
                Sortable = sortable,
                Visible = !visible.HasValue || visible.Value
            };
            Columns.Add(column);
            return this;
        }

        public GridSettings SetDataSourceUrl(string url)
        {
            DataSourceUrl = url;
            return this;
        }

        public GridSettings SetDeferLoading(string records = "0")
        {
            DeferLoading = records;
            return this;
        }

        public GridSettings SetGridId(string gridId = "dataTable")
        {
            GridId = gridId;
            return this;
        }

        public GridSettings SetPageSize(int pageSize = 20)
        {
            PageSize = pageSize;
            return this;
        }

        public GridSettings SetSearchForm(string searchFormId = "search-criteria")
        {
            SearchFormId = searchFormId;
            return this;
        }

        public GridSettings SetDefaultSorting(string columnName, SortOrder sortOrder = SortOrder.Ascendant)
        {
            if (DefaultSorting == null)
            {
                DefaultSorting = new List<SortCriteria>();
            }
            ColumnSettings column = Columns.FirstOrDefault(c => c.Name == columnName);
            if (column == null)
            {
                throw new InvalidOperationException(
                    "Column name was not found among the columns of this grid! Column name: " + columnName);
            }
            if (!column.Sortable)
            {
                throw new InvalidOperationException("Column set as default for sorting is not sortable! Column name:" +
                                                    columnName);
            }
            DefaultSorting.Add(new SortCriteria(columnName, sortOrder));
            return this;
        }
    }
}
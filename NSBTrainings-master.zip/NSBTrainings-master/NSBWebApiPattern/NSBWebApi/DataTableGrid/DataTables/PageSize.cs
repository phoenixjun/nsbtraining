﻿
namespace Pinpoint.DataTableWrapper.DataTables
{
    public enum PageSize
    {
        Default,
        Contact,
        MerchandiseOrderLine,
        MemberSearch,
        Redemption,
        CallOutcome,
        Comment,
        FrequentFlyerOrderCancellation,
        FrequentFlyerOrderResend,
        Message,
        MessageReference,
        GiftCardMemberEmail,
        SearchGiftCard
    }
}
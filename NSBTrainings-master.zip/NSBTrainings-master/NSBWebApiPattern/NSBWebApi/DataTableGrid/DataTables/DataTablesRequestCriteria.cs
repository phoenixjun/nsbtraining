﻿using System.Collections.Generic;
using Pinpoint.DataTableWrapper.DataTables.Columns;

namespace Pinpoint.DataTableWrapper.DataTables
{
    public class GridSettings1
    {
        public string GridId { get; set; }
        public string SearchFormId { get; set; }
        public int PageSize { get; set; }
        public List<ColumnSettings> Columns { get; set; }
        public string DataSourceUrl { get; set; }

    }
}
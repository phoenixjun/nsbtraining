﻿using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Web.Mvc;
using Pinpoint.DataTableWrapper.Criterias;
using Pinpoint.DataTableWrapper.Extensions;

namespace Pinpoint.DataTableWrapper.DataTables
{
    public class GridRequestCriteriaModelBinder : IModelBinder
    {
        public object BindModel(ControllerContext controllerContext, ModelBindingContext bindingContext)
        {
            var query = controllerContext.HttpContext.Request.Form;
            return ExtractModel(query);
        }
        private static GridRequestCriteria ExtractModel(NameValueCollection query)
        {
            var data = new GridRequestCriteria
            {
                Echo = query.Get("sEcho"),
                Search = query.Get("sSearch"),
                NoOfColumns = int.Parse(query.Get("iColumns")),
                GridCriteria = new GridCriteria
                {
                    Pagination =
                        new PaginationCriteria
                        {
                            PageSize = int.Parse(query.Get("iDisplayLength")),
                            StartIndex = int.Parse(query.Get("iDisplayStart"))
                        }
                }
            };

            var columns = query.Get("sColumns").Split(',').Select(s => s.Trim()).ToList();
            data.GridCriteria.SortCriteria = new List<Criterias.SortCriteria>();
            for (var i = 0; i < data.NoOfColumns; i++)
            {
                var indexOfColumnToSort = query.Get("iSortCol_" + i).ToNullableInt();
                if (indexOfColumnToSort == null || indexOfColumnToSort < 0 || indexOfColumnToSort >= data.NoOfColumns)
                {
                    continue;
                }
                var isSortable = query.Get("bSortable_" + indexOfColumnToSort.Value).ToNullableBool();
                if (isSortable != true)
                {
                    continue;
                }
                var sortDirection = query.Get("sSortDir_" + i);
                if (sortDirection == null)
                {
                    continue;
                }
                var columnName = columns[indexOfColumnToSort.Value];
                data.GridCriteria.SortCriteria.Add(new Criterias.SortCriteria(columnName,
                    sortDirection.Trim().ToLower() == "asc" ? Criterias.SortOrder.Ascendant : Criterias.SortOrder.Descendant));
            }

            return data;
        }
    }
}
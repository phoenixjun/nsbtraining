﻿namespace Pinpoint.DataTableWrapper.DataTables.Columns
{
    public class HyperLinkColumn : ColumnSettings
    {
        public HyperLinkColumn()
        {
            Sortable = false;
        }
    }
}
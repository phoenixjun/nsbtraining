﻿namespace Pinpoint.DataTableWrapper.DataTables.Columns
{
    public class ColumnSettings
    {
        public ColumnSettings()
        {
            Visible = true;
            Sortable = true;
        }

        public ColumnSettings(string propertyName)
        {
            Visible = true;
            Sortable = true;
            Name = propertyName;
        }

        public string Name { get; set; }
        public string Align { get; set; }
        public string DisplayName { get; set; }
        public virtual bool Sortable { get; set; }
        public string Width { get; set; }
        public bool Visible { get; set; }
    }
}
﻿namespace Pinpoint.DataTableWrapper.DataTables.Columns
{
    public class CheckBoxColumn : ColumnSettings
    {
        public CheckBoxColumn()
        {
            Sortable = false;
        }
    }
}
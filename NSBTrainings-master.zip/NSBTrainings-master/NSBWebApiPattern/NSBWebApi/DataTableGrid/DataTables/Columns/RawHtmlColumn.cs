﻿namespace Pinpoint.DataTableWrapper.DataTables.Columns
{
    public class RawHtmlColumn : ColumnSettings
    {
    }
}
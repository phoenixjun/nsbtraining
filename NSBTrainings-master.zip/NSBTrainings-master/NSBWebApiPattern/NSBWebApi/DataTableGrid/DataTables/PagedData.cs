﻿using System.Collections.Generic;

namespace Pinpoint.DataTableWrapper.DataTables
{
    public class PagedData<T>
    {
        public IList<T> Page { get; set; }
        public int TotalMatchedEntries { get; set; }
    }
}
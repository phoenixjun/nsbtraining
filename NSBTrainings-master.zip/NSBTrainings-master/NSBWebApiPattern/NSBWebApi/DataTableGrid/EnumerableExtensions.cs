﻿using System.Collections.Generic;
using System.Linq;

namespace Pinpoint.DataTableWrapper
{
    public static class EnumerableExtensions
    {

        public static bool HasValues<T>(this IEnumerable<T> source)
        {
            return source != null && source.Any();
        }
    }
}
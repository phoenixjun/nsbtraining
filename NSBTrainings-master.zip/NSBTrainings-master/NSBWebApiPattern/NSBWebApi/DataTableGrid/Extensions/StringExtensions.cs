﻿using System;
using System.Collections.Generic;

namespace Pinpoint.DataTableWrapper.Extensions
{
    public static class StringExtensions
    {
        public static int? ToNullableInt(this string source)
        {
            if (string.IsNullOrWhiteSpace(source))
            {
                return null;
            }

            int result;
            if (int.TryParse(source, out result))
            {
                return result;
            }
            return null;
        }

        public static decimal? ToNullableDecimal(this string source)
        {
            if (string.IsNullOrWhiteSpace(source))
            {
                return null;
            }

            decimal result;
            if (decimal.TryParse(source, out result))
            {
                return result;
            }
            return null;
        }

        public static bool? ToNullableBool(this string source)
        {
            if (string.IsNullOrWhiteSpace(source))
            {
                return null;
            }

            bool result;
            if (bool.TryParse(source, out result))
            {
                return result;
            }
            return null;
        }

        //public static IList<string> SplitToList(this string source, params string[] delimiter)
        //{
        //    if (string.IsNullOrEmpty(source))
        //    {
        //        return null;
        //    }
        //    if (delimiter == null || delimiter.Length == 0)
        //    {
        //        return new List<string> {source};
        //    }
        //    List<string> delimiters = delimiter.ToNewList().Where(d => !string.IsNullOrEmpty(d)).ToList();
        //    if (!delimiters.HasValues())
        //    {
        //        return new List<string> {source};
        //    }
        //    return source.Split(delimiters.ToArray(), StringSplitOptions.None).ToNewList();
        //}

    }
}
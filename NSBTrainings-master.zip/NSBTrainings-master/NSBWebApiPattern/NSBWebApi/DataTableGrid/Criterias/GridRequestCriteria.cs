﻿namespace Pinpoint.DataTableWrapper.Criterias
{
    public class GridRequestCriteria
    {
        public GridCriteria GridCriteria { get; set; }
        public string Echo { get; set; }
        public string Search { get; set; }
        public int NoOfColumns { get; set; }
        public int NoOfSortingColumns { get; set; }
    }
}
﻿namespace Pinpoint.DataTableWrapper.Criterias
{
    public enum SortOrder
    {
        Ascendant = 1,
        Descendant = 2
    }
}
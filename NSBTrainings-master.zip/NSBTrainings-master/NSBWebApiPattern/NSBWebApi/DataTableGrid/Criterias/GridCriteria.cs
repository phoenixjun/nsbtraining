﻿using System.Collections.Generic;

namespace Pinpoint.DataTableWrapper.Criterias
{
    public class GridCriteria
    {
        public PaginationCriteria Pagination { get; set; }
        public List<SortCriteria> SortCriteria { get; set; }
    }
}